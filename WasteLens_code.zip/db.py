# =============================================================
#  WasteLens – Database Layer
# =============================================================
import mysql.connector
from mysql.connector import Error
from config import DB_CONFIG


def get_connection():
    """Return a live MySQL connection or raise ConnectionError."""
    try:
        return mysql.connector.connect(**DB_CONFIG)
    except Error as e:
        raise ConnectionError(f"DB connection failed: {e}")


def run_query(sql: str, params: tuple = None) -> list[dict]:
    """Execute a SELECT and return list-of-dicts."""
    conn = get_connection()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute(sql, params or ())
        return cur.fetchall()
    finally:
        conn.close()


def run_update(sql: str, params: tuple = None) -> int:
    """Execute INSERT/UPDATE/DELETE, commit, return lastrowid."""
    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.execute(sql, params or ())
        conn.commit()
        return cur.lastrowid
    except Error:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_passwords():
    """
    Replace SQL placeholder hashes with real bcrypt hashes on first run.
    Also creates any missing team-member accounts automatically.
    Safe to call repeatedly – no-op for rows that are already correct.
    """
    import bcrypt
    from config import DEFAULT_PASSWORDS

    # ── 1. Fix placeholder hashes for existing users ───────────
    for email, plain in DEFAULT_PASSWORDS.items():
        rows = run_query("SELECT UserID, Password FROM User WHERE Email = %s", (email,))
        if rows and "Placeholder" in (rows[0]["Password"] or ""):
            hashed = bcrypt.hashpw(plain.encode(), bcrypt.gensalt()).decode()
            run_update("UPDATE User SET Password = %s WHERE Email = %s", (hashed, email))

    # ── 2. Auto-create team members if they don't exist yet ────
    TEAM_EXTRAS = {
        "dhanalakshmikm25@gmail.com": ("Dhana Lakshmi", "Admin"),
        "kannu1d@cmich.edu":          ("Kannu",         "Manager"),
        "chiri1s@cmich.edu":          ("Chiri",         "Staff"),
    }

    for email, (name, role_name) in TEAM_EXTRAS.items():
        existing = run_query("SELECT UserID FROM User WHERE Email=%s", (email,))
        if existing:
            continue   # already in DB – skip

        role_row = run_query("SELECT RoleID FROM Role WHERE RoleName=%s", (role_name,))
        if not role_row:
            continue

        plain  = DEFAULT_PASSWORDS.get(email, "Welcome@123")
        hashed = bcrypt.hashpw(plain.encode(), bcrypt.gensalt()).decode()

        try:
            uid = run_update(
                """INSERT INTO User (UserName, Email, Password, IsApproved, IsActive, RoleID)
                   VALUES (%s, %s, %s, 1, 1, %s)""",
                (name, email, hashed, role_row[0]["RoleID"]),
            )
            # assign to first available branch
            branch = run_query("SELECT BranchID FROM Branch ORDER BY BranchID LIMIT 1")
            if branch and uid:
                run_update(
                    "INSERT IGNORE INTO UserBranchAccess (UserID, BranchID, AccessType)"
                    " VALUES (%s, %s, 'Write')",
                    (uid, branch[0]["BranchID"]),
                )
        except Exception:
            pass   # silently skip if any constraint issue
