"""
WasteLens Launcher
Bundles with PyInstaller to create a one-click executable.
Opens the app in the default browser automatically.
"""
import sys, os, time, threading, subprocess, webbrowser

def _find_streamlit():
    """Return the streamlit executable path, trying several locations."""
    # PyInstaller temp dir
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    candidates = [
        os.path.join(os.path.dirname(sys.executable), "streamlit.exe"),
        os.path.join(os.path.dirname(sys.executable), "Scripts", "streamlit.exe"),
        os.path.join(os.path.dirname(sys.executable), "streamlit"),
        "streamlit",
    ]
    for c in candidates:
        if os.path.isfile(c):
            return c
    return "streamlit"   # hope it's on PATH

def _open_browser():
    time.sleep(3)        # wait for streamlit to start
    webbrowser.open("http://localhost:8501")

if __name__ == "__main__":
    app_dir  = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    app_py   = os.path.join(app_dir, "app.py")
    st_exe   = _find_streamlit()

    # Open browser in background
    threading.Thread(target=_open_browser, daemon=True).start()

    # Launch streamlit
    cmd = [st_exe, "run", app_py,
           "--server.port=8501",
           "--server.headless=true",
           "--browser.gatherUsageStats=false"]
    proc = subprocess.run(cmd, cwd=app_dir)
    sys.exit(proc.returncode)
