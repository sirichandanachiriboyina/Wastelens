# =============================================================
#  WasteLens – Waste Log (Add / View / Edit / Delete)
# =============================================================
import streamlit as st

st.set_page_config(
    page_title="Waste Log | WasteLens",
    page_icon="📝",
    layout="wide",
)

import pandas as pd
from datetime import datetime, date
from auth import require_auth, branch_filter_sql
from db import run_query, run_update
from utils import inject_css, render_sidebar

inject_css()
user = require_auth()
render_sidebar(user)

role = user["RoleName"]
uid  = user["UserID"]
bf   = branch_filter_sql(user)

st.title("📝 Waste Log")
st.caption("Record and manage food waste entries")

st.markdown("---")

# ══ TABS: VIEW / ADD ══════════════════════════════════════════
# after a successful add we flip to view tab automatically
_default_tab = st.session_state.pop("wl_goto_view", False)
tab_view, tab_add = st.tabs(["📋  View Logs", "➕  Add Entry"])
if _default_tab:
    # force the view tab to appear "active" via a rerun flag already consumed
    pass

# ─────────────────────────────────────────────────────────────
# TAB 1 – VIEW  (with inline edit / delete per row)
# ─────────────────────────────────────────────────────────────
with tab_view:
    fc1, fc2, fc3, fc4 = st.columns([2, 2, 2, 1])
    with fc1:
        date_from = st.date_input("From", value=date(2025, 3, 1))
    with fc2:
        date_to   = st.date_input("To",   value=date.today())
    cats = run_query("SELECT WasteCategoryID, TypeName FROM WasteCategory ORDER BY TypeName")
    cat_map = {"All": None} | {c["TypeName"]: c["WasteCategoryID"] for c in (cats or [])}
    with fc3:
        sel_cat = st.selectbox("Category", options=list(cat_map.keys()))
    with fc4:
        st.markdown("<br>", unsafe_allow_html=True)
        st.button("🔍 Search", use_container_width=True)

    cat_clause = f" AND wl.WasteCategoryID = {cat_map[sel_cat]}" if cat_map[sel_cat] else ""

    logs = run_query(
        f"""SELECT wl.WasteLogID,
                   DATE(wl.WasteDateTime) AS Date,
                   i.ItemName, wc.TypeName AS Category,
                   wr.ReasonText AS Reason,
                   wl.Quantity   AS Qty,
                   wl.EstimatedCost AS Cost,
                   b.BranchName,
                   u.UserName    AS LoggedBy,
                   wl.Notes,
                   wl.LoggedByUserID
            FROM WasteLog wl
            JOIN Item          i  ON i.ItemID           = wl.ItemID
            JOIN WasteCategory wc ON wc.WasteCategoryID = wl.WasteCategoryID
            JOIN WasteReason   wr ON wr.ReasonID        = wl.ReasonID
            JOIN Branch        b  ON b.BranchID         = wl.BranchID
            JOIN User          u  ON u.UserID           = wl.LoggedByUserID
            WHERE DATE(wl.WasteDateTime) BETWEEN %s AND %s
              {bf} {cat_clause}
            ORDER BY wl.WasteDateTime DESC""",
        (str(date_from), str(date_to)),
    )

    if not logs:
        st.info("No waste logs found for the selected filters.")
    else:
        df = pd.DataFrame(logs)
        s1, s2, s3 = st.columns(3)
        s1.metric("Entries shown", len(df))
        s2.metric("Total Qty",     f"{float(df['Qty'].sum()):.2f} kg")
        s3.metric("Total Cost",    f"RM {float(df['Cost'].sum()):.2f}")

        # decide which rows this user can edit
        editable_ids = {
            r["WasteLogID"]
            for r in logs
            if role in ("Admin", "Manager") or r["LoggedByUserID"] == uid
        }

        # ── fetch option lists for dropdowns ────────────────────
        cats_e    = run_query("SELECT WasteCategoryID, TypeName FROM WasteCategory ORDER BY TypeName")
        reasons_e = run_query("SELECT ReasonID, ReasonText FROM WasteReason ORDER BY ReasonText")
        items_e   = run_query("SELECT ItemID, ItemName, Unit, CostPerUnit FROM Item ORDER BY ItemName")
        cat_opts    = [c["TypeName"]    for c in (cats_e    or [])]
        reason_opts = [r["ReasonText"]  for r in (reasons_e or [])]
        item_map_s  = {i["ItemName"]: i for i in (items_e   or [])}
        cat_map_s   = {c["TypeName"]: c["WasteCategoryID"] for c in (cats_e    or [])}
        reason_map_s= {r["ReasonText"]: r["ReasonID"]      for r in (reasons_e or [])}

        # ── build editable dataframe ─────────────────────────────
        edit_df = pd.DataFrame({
            "ID":        [r["WasteLogID"]         for r in logs],
            "Date":      [str(r["Date"])           for r in logs],
            "Item":      [r["ItemName"]            for r in logs],
            "Category":  [r["Category"]            for r in logs],
            "Reason":    [r["Reason"]              for r in logs],
            "Qty (kg)":  [float(r["Qty"])          for r in logs],
            "Cost (RM)": [float(r["Cost"])         for r in logs],
            "Branch":    [r["BranchName"]          for r in logs],
            "Logged By": [r["LoggedBy"]            for r in logs],
            "Notes":     [r["Notes"] or ""         for r in logs],
            "🗑️ Delete": [False                    for _  in logs],
        })

        st.caption("✏️ Edit **Category, Reason, Qty, Notes** directly in the table. "
                   "Tick **🗑️ Delete** to mark rows for removal. Then click **Save Changes**.")

        edited_df = st.data_editor(
            edit_df,
            column_config={
                "ID":        st.column_config.NumberColumn("ID",        disabled=True, width="small"),
                "Date":      st.column_config.TextColumn("Date",        disabled=True, width="small"),
                "Item":      st.column_config.TextColumn("Item",        disabled=True),
                "Category":  st.column_config.SelectboxColumn("Category",  options=cat_opts),
                "Reason":    st.column_config.SelectboxColumn("Reason",    options=reason_opts),
                "Qty (kg)":  st.column_config.NumberColumn("Qty (kg)",  min_value=0.001, format="%.3f"),
                "Cost (RM)": st.column_config.NumberColumn("Cost (RM)", disabled=True, format="%.2f"),
                "Branch":    st.column_config.TextColumn("Branch",      disabled=True, width="small"),
                "Logged By": st.column_config.TextColumn("Logged By",   disabled=True, width="small"),
                "Notes":     st.column_config.TextColumn("Notes"),
                "🗑️ Delete": st.column_config.CheckboxColumn("Delete", default=False, width="small"),
            },
            disabled=[
                c for c in edit_df.columns
                if c not in ("Category", "Reason", "Qty (kg)", "Notes", "🗑️ Delete")
            ],
            hide_index=True,
            use_container_width=True,
            num_rows="fixed",
            key="waste_log_editor",
        )

        if st.button("💾 Save All Changes", type="primary", use_container_width=False):
            saved = deleted = skipped = 0
            for _, row in edited_df.iterrows():
                log_id = int(row["ID"])
                # only allow edit/delete if user has permission
                if log_id not in editable_ids:
                    skipped += 1
                    continue

                if row["🗑️ Delete"]:
                    run_update("DELETE FROM WasteLog WHERE WasteLogID=%s", (log_id,))
                    deleted += 1
                    continue

                # find original row to detect changes
                orig = next((r for r in logs if r["WasteLogID"] == log_id), None)
                if not orig:
                    continue

                new_qty    = float(row["Qty (kg)"])
                new_cat    = row["Category"]
                new_reason = row["Reason"]
                new_notes  = row["Notes"].strip() or None

                changed = (
                    abs(new_qty - float(orig["Qty"])) > 0.0001
                    or new_cat    != orig["Category"]
                    or new_reason != orig["Reason"]
                    or new_notes  != (orig["Notes"] or None)
                )
                if changed:
                    idata    = item_map_s.get(row["Item"])
                    new_cost = round(float(idata["CostPerUnit"]) * new_qty, 2) if idata else float(orig["Cost"])
                    run_update(
                        """UPDATE WasteLog
                           SET WasteCategoryID=%s, ReasonID=%s,
                               Quantity=%s, EstimatedCost=%s, Notes=%s
                           WHERE WasteLogID=%s""",
                        (cat_map_s.get(new_cat),
                         reason_map_s.get(new_reason),
                         new_qty, new_cost, new_notes, log_id),
                    )
                    saved += 1

            parts = []
            if saved:   parts.append(f"✅ {saved} row(s) updated")
            if deleted: parts.append(f"🗑️ {deleted} row(s) deleted")
            if skipped: parts.append(f"⚠️ {skipped} row(s) skipped (no permission)")
            if parts:
                st.success("  ·  ".join(parts))
                st.rerun()
            else:
                st.info("No changes detected.")

# ─────────────────────────────────────────────────────────────
# TAB 2 – ADD NEW ENTRY  (all fields in one aligned container)
# ─────────────────────────────────────────────────────────────
with tab_add:
    st.markdown(
        """
        <style>
        div[data-testid="stVerticalBlockBorderWrapper"] {
            background: linear-gradient(180deg, #ffffff 0%, #fbfefb 100%);
            border: 1px solid #d2e7d7 !important;
            border-radius: 20px !important;
            box-shadow: 0 24px 50px rgba(26, 110, 60, 0.14),
                        0 10px 24px rgba(39, 174, 96, 0.10),
                        0 4px 10px rgba(0, 0, 0, 0.06),
                        inset 0 1px 0 rgba(255, 255, 255, 0.9) !important;
            padding: 0.45rem !important;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

    items_add   = run_query("SELECT ItemID, ItemName, Unit, CostPerUnit FROM Item ORDER BY ItemName")
    cats_add    = run_query("SELECT WasteCategoryID, TypeName FROM WasteCategory ORDER BY TypeName")
    reasons_add = run_query("SELECT ReasonID, ReasonText FROM WasteReason ORDER BY ReasonText")

    if role == "Admin":
        branches_add = run_query(
            "SELECT BranchID, BranchName FROM Branch WHERE IsActive=1 ORDER BY BranchName"
        )
    else:
        ids_str = ",".join(str(i) for i in user["branch_ids"]) or "0"
        branches_add = run_query(
            f"SELECT BranchID, BranchName FROM Branch WHERE IsActive=1 AND BranchID IN ({ids_str}) ORDER BY BranchName"
        )

    # "Other" option lets staff specify a non-listed item in the Notes field
    item_names   = [i["ItemName"] for i in (items_add or [])] + ["Other (specify in Notes)"]
    item_map_add = {i["ItemName"]: i for i in (items_add or [])}
    cat_map_add  = {c["TypeName"]: c["WasteCategoryID"] for c in (cats_add or [])}
    reason_map_add = {r["ReasonText"]: r["ReasonID"] for r in (reasons_add or [])}
    branch_map_add = {b["BranchName"]: b["BranchID"] for b in (branches_add or [])}

    # ── keep item selector and live preview inside one card area ─
    with st.container(border=True):
        st.markdown("#### Add Waste Entry")
        a_item = st.selectbox("Select Food Item *", item_names, key="wl_item")
        is_other = (a_item == "Other (specify in Notes)")

        if not is_other and a_item in item_map_add:
            it = item_map_add[a_item]
            st.markdown(
                f"""<div style='background:#e8f5e9;border-radius:8px;padding:0.6rem 1rem;
                    margin-bottom:0.5rem;border-left:4px solid #27AE60'>
                    <b>📦 Unit:</b> <code>{it['Unit']}</code>
                    &nbsp;&nbsp;
                    <b>💲 Cost per unit:</b> <code>RM {float(it['CostPerUnit']):.2f} / {it['Unit']}</code>
                </div>""",
                unsafe_allow_html=True,
            )
        elif is_other:
            st.info("ℹ️ 'Other' selected — describe the item in the Notes field below. "
                    "Cost will be calculated as RM 0.00. Ask your Admin to add it to Master Data later.")

        st.markdown("---")

        col1, col2, col3 = st.columns(3)

        with col1:
            a_cat  = st.selectbox("Waste Category *", list(cat_map_add.keys()))
            unit_lbl = item_map_add[a_item]["Unit"] if (a_item in item_map_add) else "unit"
            a_qty  = st.number_input(
                f"Quantity * ({unit_lbl})",
                min_value=0.001, value=1.0, step=0.1, format="%.3f",
            )

        with col2:
            a_reason = st.selectbox("Waste Reason *", list(reason_map_add.keys()))
            a_branch = st.selectbox("Branch *", list(branch_map_add.keys()))

        with col3:
            a_date = st.date_input("Waste Date *", value=date.today())
            a_time = st.time_input("Waste Time *", value=datetime.now().time())

        # cost preview
        if not is_other and a_item in item_map_add:
            cpu      = float(item_map_add[a_item]["CostPerUnit"])
            est_cost = round(cpu * a_qty, 2)
            st.markdown(
                f"""<div style='background:#e3f2fd;border-radius:8px;padding:0.6rem 1rem;
                    border-left:4px solid #2196F3;margin:0.3rem 0'>
                    <b>💰 Estimated Cost: RM {est_cost:.2f}</b>
                    <span style='color:#555;font-size:0.82rem'>
                    &nbsp;(RM {cpu:.2f}/{unit_lbl} × {a_qty:.3f} {unit_lbl})
                    </span>
                </div>""",
                unsafe_allow_html=True,
            )
        else:
            est_cost = 0.0

        a_notes = st.text_area("Notes (optional) — required if 'Other' selected above",
                               placeholder="Describe the wasted item or any additional details…")

        add_sub = st.button("➕ Log Waste Entry", use_container_width=True, type="primary")

    if add_sub:
        if is_other and not a_notes.strip():
            st.error("Please describe the item in the Notes field when 'Other' is selected.")
        elif not a_branch:
            st.error("Please select a branch.")
        else:
            if is_other:
                # Use the first item in DB as placeholder (or a dedicated "Other" item if it exists)
                other_item = run_query(
                    "SELECT ItemID, CostPerUnit, Unit FROM Item WHERE ItemName='Other' LIMIT 1"
                )
                if not other_item:
                    # fallback: use first item in list
                    other_item = run_query("SELECT ItemID, CostPerUnit, Unit FROM Item LIMIT 1")
                item_id  = other_item[0]["ItemID"]
                est_cost = 0.0
            else:
                item_id  = item_map_add[a_item]["ItemID"]
                cpu      = float(item_map_add[a_item]["CostPerUnit"])
                est_cost = round(cpu * a_qty, 2)

            waste_dt = datetime.combine(a_date, a_time)
            run_update(
                """INSERT INTO WasteLog
                   (WasteDateTime, Quantity, EstimatedCost, Notes,
                    LoggedByUserID, BranchID, WasteCategoryID, ReasonID, ItemID)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                (waste_dt, a_qty, est_cost, a_notes or None,
                 uid, branch_map_add[a_branch], cat_map_add[a_cat],
                 reason_map_add[a_reason], item_id),
            )
            label = a_item if not is_other else f"Other ({a_notes[:30]})"
            st.success(f"✅ Logged **{a_qty:.3f} {unit_lbl}** of **{label}** → RM {est_cost:.2f}")
            st.balloons()
            st.session_state["wl_goto_view"] = True
            st.rerun()   # rerun → lands on View Logs tab