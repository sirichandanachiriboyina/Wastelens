# =============================================================
#  WasteLens – Authentication & Session Helpers
# =============================================================
import bcrypt
import streamlit as st
from db import run_query, run_update


# ── password helpers ──────────────────────────────────────────
def hash_password(plain: str) -> str:
    return bcrypt.hashpw(plain.encode(), bcrypt.gensalt()).decode()


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode(), hashed.encode())
    except Exception:
        return False


# ── login ─────────────────────────────────────────────────────
def login(email: str, password: str):
    """
    Return (user_dict, None) on success or (None, error_str) on failure.
    user_dict includes  branch_ids: list[int].
    """
    sql = """
        SELECT u.UserID, u.UserName, u.Email, u.Password,
               u.IsApproved, u.IsActive, r.RoleName,
               GROUP_CONCAT(uba.BranchID ORDER BY uba.BranchID) AS BranchIDs
        FROM   User u
        JOIN   Role r  ON r.RoleID  = u.RoleID
        LEFT JOIN UserBranchAccess uba ON uba.UserID = u.UserID
        WHERE  u.Email = %s
        GROUP BY u.UserID
    """
    rows = run_query(sql, (email,))
    if not rows:
        return None, "Invalid email or password."

    u = rows[0]
    if not verify_password(password, u["Password"]):
        return None, "Invalid email or password."
    if not u["IsActive"]:
        return None, "Account deactivated. Contact your administrator."
    if not u["IsApproved"]:
        return None, "Account pending approval. Please wait for admin."

    u["branch_ids"] = (
        [int(x) for x in u["BranchIDs"].split(",")]
        if u["BranchIDs"]
        else []
    )
    return u, None


# ── register ──────────────────────────────────────────────────
def register(username: str, email: str, password: str, branch_id: int):
    """Return (True, success_msg) or (False, error_msg)."""
    if run_query("SELECT UserID FROM User WHERE Email = %s", (email,)):
        return False, "Email already registered."

    role = run_query("SELECT RoleID FROM Role WHERE RoleName = 'Staff'")
    if not role:
        return False, "System configuration error – Staff role missing."

    hashed = hash_password(password)
    try:
        uid = run_update(
            """INSERT INTO User (UserName, Email, Password, IsApproved, IsActive, RoleID)
               VALUES (%s, %s, %s, 0, 1, %s)""",
            (username, email, hashed, role[0]["RoleID"]),
        )
        if uid and branch_id:
            run_update(
                "INSERT IGNORE INTO UserBranchAccess (UserID, BranchID, AccessType)"
                " VALUES (%s, %s, 'Write')",
                (uid, branch_id),
            )
        return True, "Registration successful! Your account is awaiting admin approval."
    except Exception as e:
        return False, f"Registration failed: {e}"


# ── session helpers ───────────────────────────────────────────
def logout():
    """Clear user session and navigate back to login."""
    for key in list(st.session_state.keys()):
        del st.session_state[key]


def require_auth():
    """Stops the page if user is not logged-in. Returns user dict."""
    if "user" not in st.session_state:
        st.markdown(
            """
            <div style='text-align:center;padding:3rem 1rem'>
                <div style='font-size:3rem'>🔒</div>
                <h3 style='color:#27AE60'>Session Expired</h3>
                <p style='color:#666'>Please log in to continue.</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            if st.button("🔑  Go to Login", use_container_width=True, type="primary"):
                st.switch_page("app.py")
        st.stop()
    return st.session_state["user"]


def require_role(allowed: list[str]):
    """Stops the page if user's role is not in *allowed*. Returns user dict."""
    user = require_auth()
    if user["RoleName"] not in allowed:
        st.error(f"⛔ Access restricted to: {', '.join(allowed)}")
        st.stop()
    return user


def branch_filter_sql(user: dict, alias: str = "wl") -> str:
    """
    Return a SQL fragment like ' AND wl.BranchID IN (1,2,3)'
    for non-Admin users, or '' for Admin (sees everything).
    """
    if user["RoleName"] == "Admin":
        return ""
    ids = user.get("branch_ids", [])
    if not ids:
        return " AND 1=0"   # no branches → see nothing
    return f" AND {alias}.BranchID IN ({','.join(str(i) for i in ids)})"
