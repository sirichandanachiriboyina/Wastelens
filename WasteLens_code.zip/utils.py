# =============================================================
#  WasteLens – Shared UI Helpers
# =============================================================
import streamlit as st
from auth import logout

# ── green theme CSS injected on every page ────────────────────
GLOBAL_CSS = """
<style>
/* ══ GENERAL ══════════════════════════════════════════════════ */
[data-testid="stAppViewContainer"] { background: #f4faf4; }
body, p, span, div, label        { color: #2C3E50; }

/* ══ SIDEBAR ══════════════════════════════════════════════════ */
[data-testid="stSidebar"] { background: #1a6e3c !important; }

/* hide Streamlit's auto-generated page nav — we build our own */
[data-testid="stSidebarNav"] { display: none !important; }

/* other sidebar text (user name, captions) */
[data-testid="stSidebar"] p,
[data-testid="stSidebar"] span,
[data-testid="stSidebar"] div     { color: #d4edda !important; }

/* custom nav links inside sidebar */
.wl-nav-link a {
    display: block !important;
    padding: 0.45rem 0.9rem !important;
    border-radius: 8px !important;
    color: #d4edda !important;
    text-decoration: none !important;
    font-size: 0.9rem !important;
    font-weight: 500 !important;
    margin-bottom: 2px !important;
}
.wl-nav-link a:hover { background: rgba(255,255,255,0.15) !important; }

/* ── sign-out button: solid red so it always pops on dark green ── */
[data-testid="stSidebar"] [data-testid="stButton"] button {
    background-color: #e74c3c !important;
    color: white !important;
    border: none !important;
    border-radius: 8px !important;
    font-weight: 700 !important;
    letter-spacing: 0.3px !important;
}
[data-testid="stSidebar"] [data-testid="stButton"] button:hover {
    background-color: #c0392b !important;
    color: white !important;
}

/* ══ METRIC CARDS ═════════════════════════════════════════════ */
[data-testid="stMetric"] {
    background: white;
    border-radius: 12px;
    padding: 1rem 1.2rem;
    box-shadow: 0 2px 8px rgba(0,0,0,.08);
    border-left: 4px solid #27AE60;
}
[data-testid="stMetricValue"] { color: #27AE60 !important; font-weight: 700; }
[data-testid="stMetricLabel"] { color: #444 !important; font-weight: 600; }
[data-testid="stMetricDelta"] { font-weight: 600; }

/* ══ TABS ══════════════════════════════════════════════════════ */
/* tab bar background */
[data-baseweb="tab-list"] {
    background: #e8f5e9 !important;
    border-radius: 8px 8px 0 0;
    padding: 4px 4px 0 4px;
    gap: 2px;
}
/* ALL tab labels visible */
[data-baseweb="tab-list"] button {
    color: #2C3E50 !important;
    font-weight: 500 !important;
    font-size: 0.9rem !important;
    background: transparent !important;
    border-radius: 6px 6px 0 0 !important;
    padding: 0.45rem 1rem !important;
}
/* selected tab */
[data-baseweb="tab-list"] button[aria-selected="true"] {
    background: white !important;
    color: #1a6e3c !important;
    font-weight: 700 !important;
    border-bottom: 3px solid #27AE60 !important;
}
/* hover on unselected tab */
[data-baseweb="tab-list"] button:hover {
    background: rgba(255,255,255,0.6) !important;
    color: #27AE60 !important;
}

/* ══ INPUT LABELS & WIDGETS ════════════════════════════════════ */
label, .stTextInput label, .stSelectbox label,
.stMultiSelect label, .stDateInput label,
.stTextArea label, .stNumberInput label,
.stRadio label, .stCheckbox label,
.stFileUploader label                { color: #2C3E50 !important;
                                       font-weight: 600 !important; }
/* radio/checkbox option text */
.stRadio div[role="radiogroup"] label,
.stCheckbox div label               { font-weight: 400 !important; color: #333 !important; }

/* widget input box text */
input, textarea, select             { color: #2C3E50 !important; }

/* ══ BUTTONS (main content) ═══════════════════════════════════ */
section.main button[kind="primary"],
[data-testid="stFormSubmitButton"] button {
    background-color: #27AE60 !important;
    color: white !important;
    border-radius: 8px !important;
    font-weight: 600 !important;
}
section.main button[kind="primary"]:hover,
[data-testid="stFormSubmitButton"] button:hover {
    background-color: #1e8449 !important;
}
/* secondary / default buttons */
section.main button[kind="secondary"] {
    border: 1.5px solid #27AE60 !important;
    color: #27AE60 !important;
    font-weight: 600 !important;
}

/* ══ EXPANDER ══════════════════════════════════════════════════ */
[data-testid="stExpander"] summary p  { color: #1a6e3c !important; font-weight: 700; }
[data-testid="stExpander"]            { border: 1px solid #c8e6c9 !important;
                                        border-radius: 8px !important; }

/* ══ CAPTIONS & INFO BOXES ════════════════════════════════════ */
.stCaption, [data-testid="stCaptionContainer"] { color: #666 !important; }
[data-testid="stAlert"]  p   { color: #2C3E50 !important; }

/* ══ DATAFRAME ════════════════════════════════════════════════ */
[data-testid="stDataFrame"] { border-radius: 8px; overflow: hidden; }

/* ══ HEADINGS ══════════════════════════════════════════════════ */
h1       { color: #1a6e3c !important; font-weight: 800 !important; }
h2, h3   { color: #27AE60 !important; font-weight: 700 !important; }
h4, h5   { color: #2C3E50 !important; font-weight: 600 !important; }
p        { color: #2C3E50 !important; }

/* ══ FORM BOX ══════════════════════════════════════════════════ */
[data-testid="stForm"] {
    background: white;
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: 0 2px 10px rgba(0,0,0,.08);
    border: 1px solid #e8f5e9;
}

/* ══ SELECT BOX DROPDOWN TEXT ═════════════════════════════════ */
[data-testid="stSelectbox"] div[data-baseweb="select"] span,
[data-testid="stMultiSelect"] div[data-baseweb="select"] span { color: #2C3E50 !important; }
</style>
"""


def inject_css():
    st.markdown(GLOBAL_CSS, unsafe_allow_html=True)


def render_sidebar(user: dict):
    """Show user info + logout in the sidebar, plus a top-bar sign-out."""

    # ── logout confirmation ─────────────────────────────────────
    if st.session_state.get("_confirm_logout"):

        st.warning("⚠️ Are you sure you want to sign out?")

        col1, col2 = st.columns(2)

        with col1:
            if st.button("❌ Cancel", use_container_width=True):
                st.session_state.pop("_confirm_logout", None)
                st.rerun()

        with col2:
            if st.button("✅ Yes, Sign Out", use_container_width=True):
                st.session_state.pop("_confirm_logout", None)
                logout()
                st.switch_page("app.py")
    

    # ── sidebar: brand + role-filtered nav + sticky sign-out ───────
    role = user["RoleName"]
    # pages each role can see
    ALL_PAGES = [
        ("📊 Dashboard",        "pages/1_Dashboard.py"),
        ("📝 Waste Log",        "pages/2_Waste_Log.py"),
        ("📦 Order Entry",      "pages/3_Order_Entry.py"),
        ("📈 Reports",          "pages/4_Reports.py"),
        ("👥 User Management",  "pages/5_User_Management.py"),
        ("⚙️ Master Data",      "pages/6_Master_Data.py"),
        ("🔧 Settings",         "pages/7_Settings.py"),
    ]
    ROLE_PAGES = {
        "Admin":   ALL_PAGES,                                       # sees everything
        "Manager": ALL_PAGES[:4] + [ALL_PAGES[5]],                 # no User Mgmt, no Settings
        "Staff":   ALL_PAGES[:3],                                   # Dashboard, Waste Log, Order Entry
    }
    visible = ROLE_PAGES.get(role, ALL_PAGES[:3])

    with st.sidebar:
        st.markdown(
            f"""
            <div style='text-align:center;padding:1rem 0 0.5rem'>
                <div style='font-size:2.5rem'>🌿</div>
                <div style='font-size:1.4rem;font-weight:700;color:#e8f5e9'>WasteLens</div>
                <div style='font-size:0.75rem;color:#a5d6a7;margin-bottom:0.4rem'>
                    Food Waste Analysis
                </div>
            </div>
            <hr style='border-color:#2e7d3266;margin:4px 0 8px'>
            <div style='text-align:center;padding:0.3rem 0 0.5rem'>
                <div style='font-size:0.95rem;font-weight:600;color:#c8e6c9'>
                    👤 {user['UserName']}
                </div>
                <span style='background:#2e9e5e;color:white;font-size:0.7rem;
                             border-radius:12px;padding:2px 10px;'>{role}</span>
            </div>
            <hr style='border-color:#2e7d3266;margin:6px 0'>
            <div style='font-size:0.7rem;color:#a5d6a7;padding:0 0.5rem 4px;
                        text-transform:uppercase;letter-spacing:1px'>Navigation</div>
            """,
            unsafe_allow_html=True,
        )
        # role-filtered nav links
        for label, page_path in visible:
            st.page_link(page_path, label=label)

        st.markdown("<hr style='border-color:#2e7d3266;margin:8px 0'>",
                    unsafe_allow_html=True)
        if st.button("🚪  Sign Out", use_container_width=True,
                     key="sidebar_signout"):
            st.session_state["_confirm_logout"] = True
            st.rerun()


def render_topbar(user: dict):
    """
    Optional top-right sign-out bar injected via HTML.
    Call after render_sidebar() if you want an extra visible logout button.
    """
    st.markdown(
        f"""
        <div style='display:flex;justify-content:flex-end;align-items:center;
                    background:white;border-radius:8px;padding:0.4rem 1rem;
                    box-shadow:0 1px 4px rgba(0,0,0,.08);margin-bottom:0.8rem'>
            <span style='color:#555;font-size:0.85rem;margin-right:1rem'>
                👤 <b>{user['UserName']}</b>
                &nbsp;
                <span style='background:#27AE60;color:white;font-size:0.7rem;
                             border-radius:10px;padding:1px 8px'>{user['RoleName']}</span>
            </span>
        </div>
        """,
        unsafe_allow_html=True,
    )


def badge(text: str, color: str = "#27AE60") -> str:
    """Return an HTML colored badge."""
    return (
        f"<span style='background:{color};color:white;font-size:0.72rem;"
        f"border-radius:10px;padding:2px 9px;font-weight:600'>{text}</span>"
    )


def status_badge(active: bool) -> str:
    return badge("Active", "#27AE60") if active else badge("Inactive", "#e74c3c")


def approval_badge(approved: bool) -> str:
    return badge("Approved", "#27AE60") if approved else badge("Pending", "#f39c12")
