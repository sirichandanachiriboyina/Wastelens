# =============================================================
#  WasteLens – Settings  (Admin only)
# =============================================================
import streamlit as st

st.set_page_config(
    page_title="Settings | WasteLens",
    page_icon="🔧",
    layout="wide",
)

import json, os, smtplib, random
from email.mime.multipart import MIMEMultipart
from email.mime.text      import MIMEText
from auth   import require_role
from utils  import inject_css, render_sidebar

inject_css()
user = require_role(["Admin"])
render_sidebar(user)

SETTINGS_FILE = os.path.join(os.path.dirname(__file__), "..", "local_settings.json")

# ── Load / Save helpers ───────────────────────────────────────
def load_settings() -> dict:
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, "r") as f:
                return json.load(f)
        except Exception:
            pass
    return {}

def save_settings(data: dict):
    with open(SETTINGS_FILE, "w") as f:
        json.dump(data, f, indent=2)

cfg = load_settings()

st.title("🔧 Settings")
st.caption("Application configuration — Admin only")

# ══════════════════════════════════════════════════════════════
#  EMAIL / GMAIL CONFIGURATION
# ══════════════════════════════════════════════════════════════
st.markdown("### 📧 Email Configuration")
st.markdown(
    "Configure your own Gmail to send OTP password-reset emails to users. "
    "Each team member running this app can set their own credentials."
)

with st.container():
    st.markdown("""
    <div style='background:#e8f5e9;border-left:4px solid #27AE60;border-radius:8px;
                padding:.9rem 1.1rem;font-size:.85rem;color:#1a5e38;margin-bottom:1rem'>
      <b>How to get your Gmail App Password (2 minutes):</b><br><br>
      1️⃣  Enable 2-Step Verification →
         <a href='https://myaccount.google.com/signinoptions/two-step-verification'
            target='_blank' style='color:#27AE60'>
            myaccount.google.com/signinoptions/two-step-verification</a><br>
      2️⃣  Create App Password →
         <a href='https://myaccount.google.com/apppasswords'
            target='_blank' style='color:#27AE60'>
            myaccount.google.com/apppasswords</a><br>
      3️⃣  App name: <b>WasteLens</b> → Copy the 16-char code → paste below
    </div>
    """, unsafe_allow_html=True)

    col1, col2 = st.columns(2)

    with col1:
        gmail_addr = st.text_input(
            "Your Gmail Address",
            value=cfg.get("sender_email", ""),
            placeholder="yourname@gmail.com",
        )
    with col2:
        app_pwd = st.text_input(
            "Gmail App Password (16 chars)",
            value=cfg.get("app_password", ""),
            placeholder="abcdefghijklmnop",
            type="password",
        )

    sender_name = st.text_input(
        "Sender Display Name",
        value=cfg.get("sender_name", "WasteLens"),
        placeholder="WasteLens",
    )

    st.markdown("<div style='height:4px'></div>", unsafe_allow_html=True)

    save_col, test_col, _ = st.columns([1.5, 1.5, 4])

    with save_col:
        if st.button("💾 Save Settings", use_container_width=True, type="primary"):
            if not gmail_addr or "@" not in gmail_addr:
                st.error("Please enter a valid Gmail address.")
            elif not app_pwd or len(app_pwd.replace(" ", "")) < 16:
                st.error("App Password must be 16 characters (remove any spaces).")
            else:
                cfg["sender_email"] = gmail_addr.strip()
                cfg["app_password"] = app_pwd.strip().replace(" ", "")
                cfg["sender_name"]  = sender_name.strip() or "WasteLens"
                cfg["smtp_host"]    = "smtp.gmail.com"
                cfg["smtp_port"]    = 587
                save_settings(cfg)
                st.success("✅ Email settings saved!")
                st.rerun()

    with test_col:
        if st.button("📨 Send Test Email", use_container_width=True):
            if not cfg.get("app_password") or not cfg.get("sender_email"):
                st.error("Save your settings first before testing.")
            else:
                test_otp = str(random.randint(100000, 999999))
                try:
                    msg = MIMEMultipart("alternative")
                    msg["Subject"] = "WasteLens – Test Email ✅"
                    msg["From"]    = f"{cfg['sender_name']} <{cfg['sender_email']}>"
                    msg["To"]      = cfg["sender_email"]

                    body = (
                        f"<div style='font-family:sans-serif;padding:20px'>"
                        f"<h2 style='color:#27AE60'>🌿 WasteLens Test Email</h2>"
                        f"<p>Your email configuration is working correctly!</p>"
                        f"<p>Sample OTP: <b style='font-size:1.4rem;letter-spacing:5px;"
                        f"color:#1a5e38'>{test_otp}</b></p>"
                        f"<p style='color:#888;font-size:.8rem'>Sent from WasteLens Settings</p>"
                        f"</div>"
                    )
                    msg.attach(MIMEText("WasteLens test email — config is working!", "plain"))
                    msg.attach(MIMEText(body, "html"))

                    with smtplib.SMTP("smtp.gmail.com", 587) as server:
                        server.ehlo()
                        server.starttls()
                        server.login(cfg["sender_email"], cfg["app_password"])
                        server.sendmail(cfg["sender_email"], cfg["sender_email"], msg.as_string())

                    st.success(f"✅ Test email sent to **{cfg['sender_email']}** — check your inbox!")
                except smtplib.SMTPAuthenticationError:
                    st.error("❌ Authentication failed — check your App Password.")
                except Exception as e:
                    st.error(f"❌ Failed to send: {e}")

# ── Current status indicator ──────────────────────────────────
st.markdown("---")
st.markdown("#### Current Status")

if cfg.get("app_password") and cfg.get("sender_email"):
    st.markdown(f"""
    <div style='background:#dcfce7;border:1px solid #86efac;border-radius:10px;
                padding:.8rem 1.2rem;display:flex;align-items:center;gap:.8rem'>
      <span style='font-size:1.4rem'>✅</span>
      <div>
        <div style='font-weight:700;color:#15803d'>Email Configured</div>
        <div style='font-size:.83rem;color:#166534'>
          Sending as <b>{cfg['sender_email']}</b> ({cfg.get('sender_name','WasteLens')})
        </div>
      </div>
    </div>
    """, unsafe_allow_html=True)
else:
    st.markdown("""
    <div style='background:#fef9c3;border:1px solid #fde047;border-radius:10px;
                padding:.8rem 1.2rem;display:flex;align-items:center;gap:.8rem'>
      <span style='font-size:1.4rem'>⚠️</span>
      <div>
        <div style='font-weight:700;color:#854d0e'>Email Not Configured</div>
        <div style='font-size:.83rem;color:#92400e'>
          OTP emails are in Demo Mode — enter your Gmail above to enable real sending.
        </div>
      </div>
    </div>
    """, unsafe_allow_html=True)
