@echo off
title WasteLens – Build Executable
color 0B
echo.
echo  =========================================
echo    WasteLens – PyInstaller Build
echo  =========================================
echo.

cd /d "%~dp0"

:: Install PyInstaller
python -m pip install -q pyinstaller

:: Collect streamlit package data location
for /f "delims=" %%i in ('python -c "import streamlit; import os; print(os.path.dirname(streamlit.__file__))"') do set ST_PATH=%%i

echo  Streamlit found at: %ST_PATH%
echo.
echo  Building... (this takes 2-5 minutes)
echo.

pyinstaller ^
  --noconfirm ^
  --onefile ^
  --windowed ^
  --name "WasteLens" ^
  --icon NONE ^
  --add-data "app.py;." ^
  --add-data "auth.py;." ^
  --add-data "db.py;." ^
  --add-data "config.py;." ^
  --add-data "utils.py;." ^
  --add-data "email_utils.py;." ^
  --add-data "pages;pages" ^
  --add-data "%ST_PATH%;streamlit" ^
  --hidden-import streamlit ^
  --hidden-import streamlit.runtime ^
  --hidden-import streamlit.web.cli ^
  --hidden-import plotly ^
  --hidden-import pandas ^
  --hidden-import bcrypt ^
  --hidden-import mysql.connector ^
  launcher.py

echo.
if exist "dist\WasteLens.exe" (
    echo  SUCCESS: dist\WasteLens.exe created!
    echo.
    echo  IMPORTANT: Copy these files alongside WasteLens.exe:
    echo    - config.py  (update DB credentials before distributing)
    echo    - pages\     folder
    echo  OR use run_wastelens.bat for the easiest distribution.
) else (
    echo  Build may have had issues – check output above.
)
echo.
pause
