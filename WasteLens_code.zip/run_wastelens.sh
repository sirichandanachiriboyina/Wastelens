#!/bin/bash
echo ""
echo "  ========================================="
echo "    WasteLens – Food Waste Analysis System"
echo "  ========================================="
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "  ERROR: Python 3 is not installed."
    echo "  Download from https://python.org/downloads"
    exit 1
fi

# Move to script directory
cd "$(dirname "$0")"

# Install dependencies
echo "  Installing dependencies (first run may take ~1 min)..."
pip3 install -q -r requirements.txt

# Open browser after 3 seconds
sleep 3 && open http://localhost:8501 &

echo ""
echo "  Starting WasteLens at http://localhost:8501"
echo "  Press Ctrl+C to stop."
echo ""

python3 -m streamlit run app.py --server.port 8501 --browser.gatherUsageStats false
