# =============================================================
#  WasteLens – Dashboard
# =============================================================
import streamlit as st

st.set_page_config(
    page_title="Dashboard | WasteLens",
    page_icon="📊",
    layout="wide",
)

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from auth import require_auth, branch_filter_sql
from db import run_query
from utils import inject_css, render_sidebar

inject_css()
user = require_auth()
render_sidebar(user)

bf = branch_filter_sql(user)   # branch filter for WasteLog queries

# ══ KPI CARDS ═════════════════════════════════════════════════
st.title("📊 Dashboard")
st.caption("Real-time waste analysis overview")

c1, c2, c3, c4 = st.columns(4)

def _val(rows, key="val"):
    return (rows[0][key] or 0) if rows else 0

waste_this  = run_query(
    f"SELECT ROUND(SUM(Quantity),2) AS val FROM WasteLog wl"
    f" WHERE WasteDateTime >= CURDATE()-INTERVAL 7 DAY {bf}"
)
waste_last  = run_query(
    f"SELECT ROUND(SUM(Quantity),2) AS val FROM WasteLog wl"
    f" WHERE WasteDateTime >= CURDATE()-INTERVAL 14 DAY"
    f" AND WasteDateTime < CURDATE()-INTERVAL 7 DAY {bf}"
)
cost_this   = run_query(
    f"SELECT ROUND(SUM(EstimatedCost),2) AS val FROM WasteLog wl"
    f" WHERE WasteDateTime >= CURDATE()-INTERVAL 7 DAY {bf}"
)
total_logs  = run_query(
    f"SELECT COUNT(*) AS val FROM WasteLog wl WHERE 1=1 {bf}"
)
active_br   = run_query("SELECT COUNT(*) AS val FROM Branch WHERE IsActive=1")

ww  = float(_val(waste_this))
wlw = float(_val(waste_last))
cw  = float(_val(cost_this))
tl  = int(_val(total_logs))
ab  = int(_val(active_br))

# only show delta when last week had data
if wlw > 0:
    delta_pct = round((ww - wlw) / wlw * 100, 1)
    delta_str = f"{delta_pct:+.1f}% vs last week"
    d_color   = "inverse"   # red = more waste = bad
else:
    delta_str = None
    d_color   = "off"

# shorten large RM values so they don't truncate
def fmt_rm(val):
    if val >= 1_000_000:
        return f"RM {val/1_000_000:.2f}M"
    if val >= 1_000:
        return f"RM {val/1_000:.1f}K"
    return f"RM {val:,.2f}"

with c1:
    st.metric("🗑️ Waste This Week", f"{ww:,.2f} kg",
              delta=delta_str, delta_color=d_color)
with c2:
    st.metric("💰 Cost This Week", fmt_rm(cw))
with c3:
    st.metric("📋 Total Log Entries", f"{tl:,}")
with c4:
    st.metric("🏢 Active Branches", f"{ab}")

st.markdown("---")

# ══ CHARTS ROW ════════════════════════════════════════════════
col_line, col_pie = st.columns([3, 2])

with col_line:
    # ── 6-Month Monthly Trend (grouped bar + cost line) ───────
    trend = run_query(
        f"""SELECT DATE_FORMAT(wl.WasteDateTime,'%Y-%m') AS Month,
                   DATE_FORMAT(wl.WasteDateTime,'%b %Y') AS MonthLabel,
                   ROUND(SUM(wl.Quantity),2)              AS Quantity_kg,
                   ROUND(SUM(wl.EstimatedCost),2)         AS Cost_RM
            FROM WasteLog wl WHERE 1=1 {bf}
            AND wl.WasteDateTime >= DATE_FORMAT(
                    CURDATE() - INTERVAL 5 MONTH, '%Y-%m-01')
            GROUP BY DATE_FORMAT(wl.WasteDateTime,'%Y-%m'),
                     DATE_FORMAT(wl.WasteDateTime,'%b %Y')
            ORDER BY Month"""
    )
    if trend:
        df_t = pd.DataFrame(trend)
        df_t["Quantity_kg"] = pd.to_numeric(df_t["Quantity_kg"], errors="coerce").fillna(0)
        df_t["Cost_RM"]     = pd.to_numeric(df_t["Cost_RM"],     errors="coerce").fillna(0)

        fig = go.Figure()
        fig.add_trace(go.Bar(
            x=df_t["MonthLabel"], y=df_t["Quantity_kg"],
            name="Waste (kg)",
            marker=dict(
                color=df_t["Quantity_kg"],
                colorscale=[[0, "#a8d5b5"], [0.5, "#27AE60"], [1, "#1a6e3c"]],
                showscale=False,
            ),
            text=df_t["Quantity_kg"].apply(lambda v: f"{v:,.0f}"),
            textposition="outside",
        ))
        fig.add_trace(go.Scatter(
            x=df_t["MonthLabel"], y=df_t["Cost_RM"],
            name="Cost (RM)", mode="lines+markers",
            line=dict(color="#e67e22", width=3, dash="dot"),
            marker=dict(size=8, color="#e67e22", symbol="diamond"),
            yaxis="y2",
        ))
        fig.update_layout(
            title="📅 Monthly Waste Trend – Last 6 Months",
            xaxis=dict(tickangle=-20),
            yaxis =dict(title="Total Waste (kg)", color="#27AE60",
                        gridcolor="#f0f0f0"),
            yaxis2=dict(title="Total Cost (RM)", overlaying="y",
                        side="right", color="#e67e22", showgrid=False),
            legend=dict(orientation="h", y=-0.22),
            plot_bgcolor="white", paper_bgcolor="white",
            margin=dict(t=50, b=30),
            hovermode="x unified",
            bargap=0.3,
        )
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No data for the last 6 months.")

with col_pie:
    cat_data = run_query(
        f"""SELECT wc.TypeName AS Category,
                   ROUND(SUM(wl.Quantity),2) AS Quantity_kg
            FROM WasteLog wl
            JOIN WasteCategory wc ON wc.WasteCategoryID=wl.WasteCategoryID
            WHERE 1=1 {bf}
            AND wl.WasteDateTime >= CURDATE()-INTERVAL 30 DAY
            GROUP BY wc.TypeName ORDER BY Quantity_kg DESC LIMIT 8"""
    )
    if cat_data:
        df_c = pd.DataFrame(cat_data)
        fig2 = px.pie(
            df_c, names="Category", values="Quantity_kg",
            title="🍰 Top Categories (30 days)",
            color_discrete_sequence=px.colors.qualitative.Set2,
            hole=0.38,
        )
        fig2.update_traces(
            textposition="inside",
            textinfo="percent",
            insidetextorientation="radial",
            hovertemplate="<b>%{label}</b><br>%{value:.2f} kg (%{percent})<extra></extra>",
        )
        fig2.update_layout(
            paper_bgcolor="white",
            showlegend=True,
            legend=dict(
                orientation="v",
                x=1.02,
                y=0.5,
                xanchor="left",
                font=dict(size=11),
            ),
            margin=dict(t=50, b=20, l=20, r=150),
            height=360,
        )
        st.plotly_chart(fig2, use_container_width=True)
    else:
        st.info("No category data available.")

# ══ BRANCH BAR CHART (Admin/Manager) ══════════════════════════
if user["RoleName"] in ("Admin", "Manager"):
    st.markdown("### 🏢 Branch Comparison – This Month")
    branch_cmp = run_query(
        """SELECT b.BranchName,
                  ROUND(SUM(wl.Quantity),2)      AS Waste_kg,
                  ROUND(SUM(wl.EstimatedCost),2) AS Cost_RM
           FROM WasteLog wl
           JOIN Branch b ON b.BranchID=wl.BranchID
           WHERE wl.WasteDateTime >= DATE_FORMAT(CURDATE(),'%Y-%m-01')
           GROUP BY b.BranchName ORDER BY Waste_kg DESC"""
    )
    if branch_cmp:
        df_b = pd.DataFrame(branch_cmp)
        fig3 = px.bar(
            df_b, x="BranchName", y="Waste_kg",
            color="Waste_kg",
            color_continuous_scale=["#a8d5b5", "#27AE60", "#1a6e3c"],
            labels={"BranchName": "Branch", "Waste_kg": "Waste (kg)"},
            title="Waste by Branch",
        )
        fig3.update_layout(
            plot_bgcolor="white", paper_bgcolor="white",
            coloraxis_showscale=False, margin=dict(t=40, b=10),
        )
        st.plotly_chart(fig3, use_container_width=True)

# ══ RECENT LOGS ════════════════════════════════════════════════
st.markdown("### 📋 Recent Waste Logs")
recent = run_query(
    f"""SELECT DATE(wl.WasteDateTime) AS Date,
               i.ItemName, wc.TypeName AS Category,
               wr.ReasonText AS Reason,
               wl.Quantity   AS `Qty (kg)`,
               wl.EstimatedCost AS `Cost (RM)`,
               b.BranchName, u.UserName AS `Logged By`
        FROM WasteLog wl
        JOIN Item          i  ON i.ItemID           = wl.ItemID
        JOIN WasteCategory wc ON wc.WasteCategoryID = wl.WasteCategoryID
        JOIN WasteReason   wr ON wr.ReasonID        = wl.ReasonID
        JOIN Branch        b  ON b.BranchID         = wl.BranchID
        JOIN User          u  ON u.UserID           = wl.LoggedByUserID
        WHERE 1=1 {bf}
        ORDER BY wl.WasteDateTime DESC LIMIT 15"""
)
if recent:
    df_r = pd.DataFrame(recent)
    df_r["Cost (RM)"] = df_r["Cost (RM)"].apply(lambda x: f"RM {x:.2f}")
    df_r["Qty (kg)"]  = df_r["Qty (kg)"].apply(lambda x: f"{x:.3f}")
    st.dataframe(df_r, use_container_width=True, hide_index=True)
else:
    st.info("No waste logs found.")
