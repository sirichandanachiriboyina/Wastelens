# =============================================================
#  WasteLens – Order Entry  (fixes: upsert preview + logout)
# =============================================================
import streamlit as st

st.set_page_config(
    page_title="Order Entry | WasteLens",
    page_icon="📦",
    layout="wide",
)

import pandas as pd
import plotly.express as px
from datetime import date
from auth import require_auth
from db import run_query, run_update
from utils import inject_css, render_sidebar

inject_css()
user = require_auth()
render_sidebar(user)          # ← sidebar already has Sign-Out button

role = user["RoleName"]
uid  = user["UserID"]

st.title("📦 Order Entry")
st.caption("Record daily customer order counts per branch")

# ── branch access ──────────────────────────────────────────────
if role == "Admin":
    branches = run_query(
        "SELECT BranchID, BranchName FROM Branch WHERE IsActive=1 ORDER BY BranchName"
    )
else:
    ids_str  = ",".join(str(i) for i in user["branch_ids"]) or "0"
    branches = run_query(
        f"SELECT BranchID, BranchName FROM Branch"
        f" WHERE IsActive=1 AND BranchID IN ({ids_str}) ORDER BY BranchName"
    )
branch_map = {b["BranchName"]: b["BranchID"] for b in (branches or [])}

# ══ TABS ══════════════════════════════════════════════════════
tab_add, tab_view, tab_today = st.tabs(
    ["➕  Record Orders", "📋  Order History", "📅  Today's Summary"]
)

# ─────────────────────────────────────────────────────────────
# TAB 1 – RECORD ORDERS
# Branch + date are OUTSIDE the form so we can preview existing record
# ─────────────────────────────────────────────────────────────
with tab_add:
    st.markdown("#### Record Order Count")

    # ── selectors OUTSIDE the form (dynamic preview) ──────────
    sel1, sel2 = st.columns(2)
    with sel1:
        o_branch = st.selectbox("Branch *", list(branch_map.keys()), key="oe_branch")
    with sel2:
        o_date = st.date_input("Date *", value=date.today(), key="oe_date")

    # ── live preview: check if record already exists ───────────
    existing = run_query(
        "SELECT OrderID, OrderCount, Notes FROM OrderEntry "
        "WHERE BranchID=%s AND OrderDate=%s",
        (branch_map[o_branch], str(o_date)),
    )

    if existing:
        ex = existing[0]
        st.warning(
            f"⚠️  **Existing record found** — "
            f"**{o_branch}** on **{o_date}** already has "
            f"**{ex['OrderCount']:,} orders** recorded.  "
            f"Submitting below will **UPDATE** (replace) it."
        )
        default_count = int(ex["OrderCount"])
        default_notes = ex["Notes"] or ""
    else:
        st.success(f"✅  No record yet for **{o_branch}** on **{o_date}** — will create new entry.")
        default_count = 0
        default_notes = ""

    # ── form (only count + notes inside) ──────────────────────
    with st.form("order_entry_form", clear_on_submit=True):
        fc1, fc2 = st.columns(2)
        with fc1:
            o_count = st.number_input(
                "Order Count *",
                min_value=0,
                value=default_count,
                step=1,
                help="Total customer orders served this day",
            )
        with fc2:
            o_notes = st.text_area(
                "Notes (optional)",
                value=default_notes,
                placeholder="e.g. Lunch rush, Public holiday…",
            )
        sub = st.form_submit_button("💾 Save Order Count", use_container_width=True)

    if sub:
        if o_count <= 0:
            st.error("Order count must be greater than 0.")
        else:
            action = "Updated" if existing else "Saved"
            run_update(
                """INSERT INTO OrderEntry
                       (OrderDate, OrderCount, Notes, EnteredByUserID, BranchID)
                   VALUES (%s, %s, %s, %s, %s)
                   ON DUPLICATE KEY UPDATE
                       OrderCount       = VALUES(OrderCount),
                       Notes            = VALUES(Notes),
                       EnteredByUserID  = VALUES(EnteredByUserID)""",
                (str(o_date), o_count, o_notes or None, uid, branch_map[o_branch]),
            )
            st.success(
                f"✅ {action} — **{o_branch}** | **{o_date}** | **{o_count:,} orders**"
            )
            st.rerun()   # refresh so the preview updates immediately

# ─────────────────────────────────────────────────────────────
# TAB 2 – ORDER HISTORY
# Source: OrderEntry table (JOIN Branch + User)
# ─────────────────────────────────────────────────────────────
with tab_view:
    st.caption("📂 Data source: **OrderEntry** table → joined with **Branch** and **User**")

    hf1, hf2, hf3 = st.columns([2, 2, 2])
    with hf1:
        h_from  = st.date_input("From", value=date(2025, 3, 1), key="h_from")
    with hf2:
        h_to    = st.date_input("To",   value=date.today(),     key="h_to")
    with hf3:
        h_branch = st.selectbox("Branch", ["All"] + list(branch_map.keys()), key="h_branch")

    br_clause = ""
    if h_branch != "All" and h_branch in branch_map:
        br_clause = f" AND oe.BranchID = {branch_map[h_branch]}"
    elif role != "Admin" and user["branch_ids"]:
        ids_str = ",".join(str(i) for i in user["branch_ids"])
        br_clause = f" AND oe.BranchID IN ({ids_str})"

    history = run_query(
        f"""SELECT oe.OrderID,
                   oe.OrderDate         AS Date,
                   b.BranchName         AS Branch,
                   oe.OrderCount        AS `Order Count`,
                   u.UserName           AS `Entered By`,
                   oe.Notes
            FROM   OrderEntry oe
            JOIN   Branch b ON b.BranchID = oe.BranchID
            JOIN   User   u ON u.UserID   = oe.EnteredByUserID
            WHERE  oe.OrderDate BETWEEN %s AND %s {br_clause}
            ORDER  BY oe.OrderDate DESC, b.BranchName""",
        (str(h_from), str(h_to)),
    )

    if not history:
        st.info("No order records found for the selected filters.")
    else:
        df_h = pd.DataFrame(history)
        s1, s2, s3 = st.columns(3)
        s1.metric("Records",       len(df_h))
        s2.metric("Total Orders",  f"{df_h['Order Count'].sum():,}")
        s3.metric("Daily Average", f"{df_h['Order Count'].mean():,.0f}")

        st.dataframe(
            df_h.drop(columns=["OrderID"]),
            use_container_width=True,
            hide_index=True,
        )

        # trend chart – bar + line combo
        if len(df_h) > 1:
            import plotly.graph_objects as go
            df_chart = df_h.groupby("Date")["Order Count"].sum().reset_index()
            df_chart["MA7"] = (
                df_chart["Order Count"].rolling(7, min_periods=1).mean().round(0)
            )
            fig = go.Figure()
            fig.add_trace(go.Bar(
                x=df_chart["Date"], y=df_chart["Order Count"],
                name="Daily Orders",
                marker_color="#a8d5b5",
            ))
            
            fig.update_layout(
                title="Order Count Trend (Bar) + 7-Day Moving Average",
                xaxis_title="Date", yaxis_title="Orders",
                plot_bgcolor="white", paper_bgcolor="white",
                legend=dict(orientation="h", y=-0.2),
                hovermode="x unified",
                margin=dict(t=40, b=10),
            )
            st.plotly_chart(fig, use_container_width=True)

        # Edit / Delete (Admin / Manager)
        if role in ("Admin", "Manager"):
            st.markdown("#### ✏️ Edit / Delete an Order Entry")
            ord_labels = {
                f"#{r['OrderID']} – {r['Date']} – {r['Branch']} ({r['Order Count']} orders)": r["OrderID"]
                for r in history
            }
            sel_ord = st.selectbox("Select entry", list(ord_labels.keys()), key="sel_ord")
            sel_oid = ord_labels[sel_ord]
            sel_row = next(r for r in history if r["OrderID"] == sel_oid)

            with st.expander("Edit this entry"):
                with st.form(f"edit_ord_{sel_oid}"):
                    new_count = st.number_input("Order Count", min_value=0,
                                                value=int(sel_row["Order Count"]))
                    new_notes = st.text_area("Notes", value=sel_row["Notes"] or "")
                    save_ord  = st.form_submit_button("💾 Save")
                if save_ord:
                    run_update(
                        "UPDATE OrderEntry SET OrderCount=%s, Notes=%s WHERE OrderID=%s",
                        (new_count, new_notes or None, sel_oid),
                    )
                    st.success("✅ Updated.")
                    st.rerun()

            if st.button(f"🗑️ Delete order #{sel_oid}", type="primary"):
                run_update("DELETE FROM OrderEntry WHERE OrderID=%s", (sel_oid,))
                st.success("Deleted.")
                st.rerun()

# ─────────────────────────────────────────────────────────────
# TAB 3 – TODAY'S SUMMARY
# ─────────────────────────────────────────────────────────────
with tab_today:
    st.markdown(f"#### Orders for **{date.today().strftime('%A, %d %B %Y')}**")

    br_today_clause = ""
    if role != "Admin" and user["branch_ids"]:
        ids_str = ",".join(str(i) for i in user["branch_ids"])
        br_today_clause = f" AND b.BranchID IN ({ids_str})"

    today_data = run_query(
        f"""SELECT b.BranchName                    AS Branch,
                   COALESCE(oe.OrderCount, 0)      AS `Orders Today`,
                   oe.Notes,
                   CASE WHEN oe.OrderID IS NOT NULL THEN 'Recorded'
                        ELSE 'Missing' END         AS Status
            FROM   Branch b
            LEFT JOIN OrderEntry oe
                   ON oe.BranchID  = b.BranchID
                  AND oe.OrderDate = CURDATE()
            WHERE  b.IsActive = 1 {br_today_clause}
            ORDER  BY b.BranchName"""
    )

    if today_data:
        df_td       = pd.DataFrame(today_data)
        total_today = df_td["Orders Today"].sum()
        recorded    = (df_td["Status"] == "Recorded").sum()
        missing     = (df_td["Status"] == "Missing").sum()

        col_a, col_b, col_c, col_d = st.columns(4)
        col_a.metric("Total Orders Today",  f"{total_today:,}")
        col_b.metric("Branches Recorded",   f"{recorded}")
        col_c.metric("Branches Missing",    f"{missing}")
        col_d.metric("Avg Orders / Branch",
                     f"{total_today / max(recorded, 1):,.0f}")

        def highlight_missing(row):
            if row["Status"] == "Missing":
                return ["background-color:#fff3cd"] * len(row)
            return [""] * len(row)

        st.dataframe(
            df_td.style.apply(highlight_missing, axis=1),
            use_container_width=True,
            hide_index=True,
        )

        if missing > 0:
            st.warning(f"⚠️  **{missing}** branch(es) have not recorded orders today. "
                       "Go to ➕ Record Orders to add them.")

    # Waste-per-Order ratio chart
    st.markdown("#### 📊 Waste-per-Order Ratio (this month)")
    ratio_data = run_query(
        """SELECT b.BranchName,
                  ROUND(SUM(ds.TotalWaste_kg),2)  AS Waste_kg,
                  SUM(ds.OrderCount)               AS Orders,
                  ROUND(SUM(ds.TotalWaste_kg)/NULLIF(SUM(ds.OrderCount),0),4)
                      AS WastePerOrder_kg
           FROM   vw_DailyBranchSummary ds
           JOIN   Branch b ON b.BranchID = ds.BranchID
           WHERE  ds.SummaryDate >= DATE_FORMAT(CURDATE(),'%Y-%m-01')
           GROUP  BY b.BranchName
           HAVING Orders > 0
           ORDER  BY WastePerOrder_kg DESC"""
    )
    if ratio_data:
        df_ratio = pd.DataFrame(ratio_data)
        fig2 = px.bar(
            df_ratio, x="BranchName", y="WastePerOrder_kg",
            color="WastePerOrder_kg",
            color_continuous_scale=["#a8d5b5", "#27AE60", "#1a6e3c"],
            labels={"BranchName": "Branch", "WastePerOrder_kg": "kg / order"},
            title="Waste per Order by Branch (this month)",
            text="WastePerOrder_kg",
        )
        fig2.update_traces(texttemplate="%{text:.4f} kg", textposition="outside")
        fig2.update_layout(
            plot_bgcolor="white", paper_bgcolor="white",
            coloraxis_showscale=False, margin=dict(t=40, b=10),
        )
        st.plotly_chart(fig2, use_container_width=True)
    else:
        st.info("No data yet for waste-per-order ratio this month.")
