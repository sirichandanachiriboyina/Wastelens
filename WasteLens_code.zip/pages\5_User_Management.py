# =============================================================
#  WasteLens – User Management (Admin only)
# =============================================================
import streamlit as st

st.set_page_config(
    page_title="User Management | WasteLens",
    page_icon="👥",
    layout="wide",
)

import pandas as pd
from auth import require_role
from db import run_query, run_update
from utils import inject_css, render_sidebar, badge

inject_css()
user = require_role(["Admin"])
render_sidebar(user)

st.title("👥 User Management")
st.caption("Manage user accounts, roles, and branch access")

# ══ STAT CARDS ════════════════════════════════════════════════
stats = run_query(
    """SELECT COUNT(*)                               AS Total,
              SUM(IsActive=1 AND IsApproved=1)       AS Active,
              SUM(IsApproved=0 AND IsActive=1)       AS Pending,
              SUM(IsActive=0)                        AS Inactive
       FROM User"""
)
if stats:
    s = stats[0]
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Users",    f"{s['Total']:,}")
    c2.metric("Active Users",   f"{s['Active']:,}")
    c3.metric("Pending Approval", f"{s['Pending']:,}")
    c4.metric("Inactive Users", f"{s['Inactive']:,}")

st.markdown("---")

# ══ TABS ══════════════════════════════════════════════════════
tab_all, tab_pending, tab_add, tab_branch = st.tabs(
    ["📋 All Users", "⏳ Pending Approval", "➕ Add User", "🔗 Branch Access"]
)

# ─────────────────────────────────────────────────────────────
# TAB 1 – ALL USERS
# ─────────────────────────────────────────────────────────────
with tab_all:
    # Search / filter
    sf1, sf2 = st.columns([3, 1])
    with sf1:
        search = st.text_input("🔍 Search by name or email", placeholder="type to filter…")
    with sf2:
        role_filter = st.selectbox("Role", ["All", "Admin", "Manager", "Staff"])

    role_clause = "" if role_filter == "All" else f" AND r.RoleName = '{role_filter}'"
    search_clause = ""
    search_params: list = []
    if search:
        search_clause = " AND (u.UserName LIKE %s OR u.Email LIKE %s)"
        search_params = [f"%{search}%", f"%{search}%"]

    all_users = run_query(
        f"""SELECT u.UserID, u.UserName, u.Email,
                   r.RoleName,
                   u.IsApproved, u.IsActive,
                   DATE(u.CreatedAt) AS Joined,
                   COUNT(uba.BranchID) AS Branches
            FROM   User u
            JOIN   Role r ON r.RoleID = u.RoleID
            LEFT JOIN UserBranchAccess uba ON uba.UserID = u.UserID
            WHERE  1=1 {role_clause} {search_clause}
            GROUP  BY u.UserID
            ORDER  BY u.CreatedAt DESC""",
        tuple(search_params),
    )

    if not all_users:
        st.info("No users found.")
    else:
        roles_avail = run_query("SELECT RoleID, RoleName FROM Role WHERE IsActive=1")
        role_map    = {r["RoleName"]: r["RoleID"] for r in roles_avail}

        total_shown = len(all_users)
        st.caption(f"Showing **{total_shown}** user{'s' if total_shown != 1 else ''}")
        st.markdown("<div style='height:6px'></div>", unsafe_allow_html=True)

        ROLE_META = {
            "Admin":   {"color": "#7c3aed", "bg": "#f5f3ff", "icon": "👑"},
            "Manager": {"color": "#0369a1", "bg": "#e0f2fe", "icon": "🏢"},
            "Staff":   {"color": "#15803d", "bg": "#dcfce7", "icon": "👤"},
        }

        for r in all_users:
            status_text  = ("Active"   if r["IsActive"] and r["IsApproved"]
                            else "Pending"  if not r["IsApproved"] and r["IsActive"]
                            else "Inactive")
            status_cfg = {
                "Active":   {"dot": "●", "color": "#16a34a", "bg": "#dcfce7"},
                "Pending":  {"dot": "●", "color": "#d97706", "bg": "#fef9c3"},
                "Inactive": {"dot": "●", "color": "#dc2626", "bg": "#fee2e2"},
            }[status_text]

            rm = ROLE_META.get(r["RoleName"], {"color": "#555", "bg": "#eee", "icon": "👤"})

            # ── initials avatar ─────────────────────────────────
            parts    = r["UserName"].split()
            initials = (parts[0][0] + (parts[-1][0] if len(parts) > 1 else "")).upper()

            # ── render card ─────────────────────────────────────
            with st.container():
                card_html = (
                    f"<div style='background:white;border-radius:14px;"
                    f"border:1px solid #e5e7eb;"
                    f"box-shadow:0 1px 6px rgba(0,0,0,.06);"
                    f"padding:.9rem 1.2rem .5rem;margin-bottom:.5rem'>"
                    f"<div style='display:flex;align-items:center;gap:1rem;flex-wrap:wrap'>"
                    f"<div style='width:44px;height:44px;border-radius:50%;"
                    f"background:{rm['bg']};color:{rm['color']};"
                    f"display:flex;align-items:center;justify-content:center;"
                    f"font-weight:800;font-size:1rem;flex-shrink:0'>{initials}</div>"
                    f"<div style='flex:1;min-width:160px'>"
                    f"<div style='font-weight:700;color:#111827;font-size:.95rem'>{r['UserName']}</div>"
                    f"<div style='color:#6b7280;font-size:.80rem;margin-top:1px'>{r['Email']}</div>"
                    f"</div>"
                    f"<span style='background:{rm['bg']};color:{rm['color']};"
                    f"border-radius:20px;padding:4px 14px;"
                    f"font-size:.76rem;font-weight:700;white-space:nowrap'>"
                    f"{rm['icon']} {r['RoleName']}</span>"
                    f"<span style='background:{status_cfg['bg']};color:{status_cfg['color']};"
                    f"border-radius:20px;padding:4px 14px;"
                    f"font-size:.76rem;font-weight:700;white-space:nowrap'>"
                    f"{status_cfg['dot']} {status_text}</span>"
                    f"<span style='color:#9ca3af;font-size:.75rem;white-space:nowrap'>"
                    f"Joined {r['Joined']} &nbsp;|&nbsp; "
                    f"{r['Branches']} branch{'es' if r['Branches'] != 1 else ''}</span>"
                    f"</div></div>"
                )
                st.markdown(card_html, unsafe_allow_html=True)

                # action bar (pure Streamlit buttons — no mixing with HTML)
                _, ab1, ab2, ab3, ab4, ab5 = st.columns([0.05, 1.2, 1.2, 1.2, 2.0, 0.8])

                with ab1:
                    if not r["IsApproved"]:
                        if st.button("✅ Approve", key=f"app_{r['UserID']}",
                                     use_container_width=True):
                            run_update("UPDATE User SET IsApproved=1 WHERE UserID=%s",
                                       (r["UserID"],))
                            st.rerun()
                    else:
                        st.markdown(
                            "<p style='color:#16a34a;font-size:.8rem;font-weight:600;"
                            "margin:6px 0 0'>✅ Approved</p>",
                            unsafe_allow_html=True,
                        )

                with ab2:
                    if r["IsActive"]:
                        if st.button("🔒 Deactivate", key=f"deact_{r['UserID']}",
                                     use_container_width=True):
                            run_update("UPDATE User SET IsActive=0 WHERE UserID=%s",
                                       (r["UserID"],))
                            st.rerun()
                    else:
                        if st.button("🔓 Activate", key=f"act_{r['UserID']}",
                                     use_container_width=True):
                            run_update("UPDATE User SET IsActive=1 WHERE UserID=%s",
                                       (r["UserID"],))
                            st.rerun()

                with ab3:
                    st.markdown(
                        "<p style='color:#6b7280;font-size:.76rem;margin:6px 0 2px'>"
                        "Change Role</p>",
                        unsafe_allow_html=True,
                    )

                with ab4:
                    cur_idx = list(role_map.keys()).index(r["RoleName"]) \
                              if r["RoleName"] in role_map else 0
                    new_role_sel = st.selectbox(
                        "role", list(role_map.keys()), index=cur_idx,
                        key=f"role_{r['UserID']}", label_visibility="collapsed",
                    )

                with ab5:
                    if new_role_sel != r["RoleName"]:
                        if st.button("💾 Save", key=f"saverole_{r['UserID']}",
                                     use_container_width=True):
                            run_update(
                                "UPDATE User SET RoleID=%s WHERE UserID=%s",
                                (role_map[new_role_sel], r["UserID"]),
                            )
                            st.rerun()

                st.markdown("<div style='height:2px'></div>", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────
# TAB 2 – PENDING APPROVAL
# ─────────────────────────────────────────────────────────────
with tab_pending:
    st.markdown("#### Users Awaiting Approval")
    pending = run_query(
        """SELECT u.UserID, u.UserName, u.Email,
                  r.RoleName, DATE(u.CreatedAt) AS Registered,
                  GROUP_CONCAT(b.BranchName SEPARATOR ', ') AS Branches
           FROM   User u
           JOIN   Role r ON r.RoleID = u.RoleID
           LEFT JOIN UserBranchAccess uba ON uba.UserID = u.UserID
           LEFT JOIN Branch b ON b.BranchID = uba.BranchID
           WHERE  u.IsApproved=0 AND u.IsActive=1
           GROUP  BY u.UserID
           ORDER  BY u.CreatedAt"""
    )

    if not pending:
        st.success("🎉 No pending users — all accounts are approved!")
    else:
        for p in pending:
            with st.container():
                pc1, pc2, pc3, pc4 = st.columns([3, 2, 1, 1])
                with pc1:
                    st.markdown(
                        f"**{p['UserName']}** &nbsp;&nbsp; "
                        f"<span style='color:#777;font-size:0.85rem'>{p['Email']}</span>",
                        unsafe_allow_html=True,
                    )
                    st.caption(f"Branch: {p['Branches'] or '—'}  |  Registered: {p['Registered']}")
                with pc2:
                    st.markdown(
                        badge(p["RoleName"], "#3498db"),
                        unsafe_allow_html=True,
                    )
                with pc3:
                    if st.button("✅ Approve", key=f"ap_{p['UserID']}",
                                 use_container_width=True):
                        run_update(
                            "UPDATE User SET IsApproved=1 WHERE UserID=%s",
                            (p["UserID"],),
                        )
                        st.success(f"Approved {p['UserName']}.")
                        st.rerun()
                with pc4:
                    if st.button("🗑️ Reject", key=f"rj_{p['UserID']}",
                                 use_container_width=True):
                        run_update(
                            "UPDATE User SET IsActive=0 WHERE UserID=%s",
                            (p["UserID"],),
                        )
                        st.warning(f"Rejected {p['UserName']}.")
                        st.rerun()
                st.markdown("<hr style='margin:4px 0'>", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────
# TAB 3 – ADD USER (admin creates an account directly)
# ─────────────────────────────────────────────────────────────
with tab_add:
    st.markdown("#### Create New User Account")
    roles_all    = run_query("SELECT RoleID, RoleName FROM Role WHERE IsActive=1")
    branches_all = run_query(
        "SELECT BranchID, BranchName FROM Branch WHERE IsActive=1 ORDER BY BranchName"
    )
    role_map2   = {r["RoleName"]: r["RoleID"] for r in roles_all}
    branch_map2 = {b["BranchName"]: b["BranchID"] for b in branches_all}

    # ── Name row (mirrors Register form) ──────────────────────
    fn_col, ln_col = st.columns(2)
    with fn_col:
        nu_first = st.text_input("First Name *", placeholder="Jane",  key="au_first")
    with ln_col:
        nu_last  = st.text_input("Last Name *",  placeholder="Doe",   key="au_last")

    # ── Email ──────────────────────────────────────────────────
    nu_email = st.text_input("Email Address *", placeholder="jane@example.com", key="au_email")

    # ── Role + Branch row ──────────────────────────────────────
    r1, r2 = st.columns(2)
    with r1:
        nu_role   = st.selectbox("Role *", list(role_map2.keys()), key="au_role")
    with r2:
        nu_branch = st.multiselect("Branch Access *", list(branch_map2.keys()), key="au_branch")

    # ── Password row ───────────────────────────────────────────
    p1, p2 = st.columns(2)
    with p1:
        nu_pass  = st.text_input("Password *",         type="password",
                                  placeholder="Min 8 chars…", key="au_pass")
    with p2:
        nu_pass2 = st.text_input("Confirm Password *", type="password",
                                  placeholder="Repeat password", key="au_pass2")

    nu_approve = st.checkbox("Auto-approve account", value=True, key="au_approve")

    with st.form("admin_add_user", clear_on_submit=False):
        st.caption("Review the details above, then click Create User.")
        add_sub = st.form_submit_button("➕ Create User", use_container_width=True)

    if add_sub:
        nu_name = f"{nu_first.strip()} {nu_last.strip()}".strip()
        from auth import hash_password
        if not all([nu_first, nu_last, nu_email, nu_pass, nu_pass2, nu_branch]):
            st.error("Please fill in all required fields.")
        elif nu_pass != nu_pass2:
            st.error("❌ Passwords do not match.")
        elif len(nu_pass) < 8:
            st.error("Password must be at least 8 characters.")
        elif run_query("SELECT UserID FROM User WHERE Email=%s", (nu_email.strip().lower(),)):
            st.error("❌ That email address is already registered.")
        else:
            hashed  = hash_password(nu_pass)
            new_uid = run_update(
                """INSERT INTO User (UserName, Email, Password, IsApproved, IsActive, RoleID)
                   VALUES (%s, %s, %s, %s, 1, %s)""",
                (nu_name, nu_email.strip().lower(), hashed,
                 1 if nu_approve else 0, role_map2[nu_role]),
            )
            for br in nu_branch:
                run_update(
                    "INSERT IGNORE INTO UserBranchAccess (UserID, BranchID, AccessType)"
                    " VALUES (%s, %s, 'Write')",
                    (new_uid, branch_map2[br]),
                )
            st.success(f"✅ User **{nu_name}** created successfully!")
            st.rerun()

# ─────────────────────────────────────────────────────────────
# TAB 4 – BRANCH ACCESS
# ─────────────────────────────────────────────────────────────
with tab_branch:
    st.markdown("#### Manage User Branch Access")

    all_u2 = run_query(
        """SELECT u.UserID, u.UserName, u.Email, r.RoleName
           FROM User u JOIN Role r ON r.RoleID=u.RoleID
           WHERE u.IsActive=1 ORDER BY u.UserName"""
    )
    u_map2 = {
        f"{u['UserName']} ({u['Email']})": u["UserID"] for u in all_u2
    }

    sel_u_label = st.selectbox("Select User", list(u_map2.keys()), key="ba_user")
    sel_u_id    = u_map2[sel_u_label]

    current_access = run_query(
        """SELECT uba.BranchID, b.BranchName, uba.AccessType
           FROM UserBranchAccess uba
           JOIN Branch b ON b.BranchID=uba.BranchID
           WHERE uba.UserID=%s""",
        (sel_u_id,),
    )

    all_br2 = run_query(
        "SELECT BranchID, BranchName FROM Branch WHERE IsActive=1 ORDER BY BranchName"
    )
    br_map2 = {b["BranchName"]: b["BranchID"] for b in all_br2}
    # Filter out any branches that are now inactive (e.g. after branch cap)
    current_br_names = [r["BranchName"] for r in current_access
                        if r["BranchName"] in br_map2]

    st.markdown(f"**Current access:** {', '.join(current_br_names) or 'None'}")

    with st.form("branch_access_form"):
        new_branches = st.multiselect(
            "Assign Branches", list(br_map2.keys()),
            default=current_br_names,
        )
        access_type = st.selectbox("Access Type", ["Write", "Read", "Admin"])
        ba_sub = st.form_submit_button("💾 Update Branch Access", use_container_width=True)

    if ba_sub:
        # remove old access and re-insert
        run_update("DELETE FROM UserBranchAccess WHERE UserID=%s", (sel_u_id,))
        for br in new_branches:
            run_update(
                "INSERT IGNORE INTO UserBranchAccess (UserID, BranchID, AccessType)"
                " VALUES (%s, %s, %s)",
                (sel_u_id, br_map2[br], access_type),
            )
        st.success("✅ Branch access updated.")
        st.rerun()
