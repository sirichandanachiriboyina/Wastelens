@echo off
title WasteLens – Startup
color 0A
echo.
echo  =========================================
echo    WasteLens – Food Waste Analysis System
echo  =========================================
echo.

:: ── Check Python ─────────────────────────────────────────────
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  ERROR: Python is not installed or not on PATH.
    echo  Download from https://python.org and tick "Add to PATH".
    pause
    exit /b 1
)

:: ── Move to app folder ────────────────────────────────────────
cd /d "%~dp0"

:: ── Install / upgrade dependencies ───────────────────────────
echo  Installing dependencies (first run may take ~1 min)...
python -m pip install -q -r requirements.txt

:: ── Start app ─────────────────────────────────────────────────
echo.
echo  Starting WasteLens... opening http://localhost:8501
echo  Press Ctrl+C to stop.
echo.
start "" http://localhost:8501
python -m streamlit run app.py --server.port 8501 --browser.gatherUsageStats false
pause
