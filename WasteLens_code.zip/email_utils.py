# =============================================================
#  WasteLens – Email Utility  (Gmail SMTP + OTP mailer)
# =============================================================
import smtplib, json, os
from email.mime.multipart import MIMEMultipart
from email.mime.text      import MIMEText
from config import EMAIL_CONFIG

_SETTINGS_FILE = os.path.join(os.path.dirname(__file__), "local_settings.json")

def _get_email_cfg() -> dict:
    """Read from local_settings.json first; fall back to config.py."""
    if os.path.exists(_SETTINGS_FILE):
        try:
            with open(_SETTINGS_FILE, "r") as f:
                local = json.load(f)
            if local.get("app_password") and local.get("sender_email"):
                return local
        except Exception:
            pass
    return EMAIL_CONFIG


def send_otp_email(to_email: str, otp_code: str, user_name: str = "") -> tuple[bool, str]:
    """
    Send a styled OTP email via Gmail SMTP.
    Returns (success: bool, message: str).
    """
    cfg = _get_email_cfg()
    if not cfg.get("app_password"):
        return False, "EMAIL_NOT_CONFIGURED"

    subject = "WasteLens – Your Password Reset Code"
    greeting = f"Hi {user_name}," if user_name else "Hello,"

    html_body = f"""
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <style>
        body {{ font-family: 'Segoe UI', Arial, sans-serif; background: #f0faf5; margin:0; padding:0; }}
        .wrapper {{ max-width:520px; margin:40px auto; background:white;
                   border-radius:16px; overflow:hidden;
                   box-shadow:0 4px 24px rgba(0,0,0,.10); }}
        .header  {{ background:linear-gradient(135deg,#1a5e38,#27AE60);
                   padding:2rem; text-align:center; }}
        .header h1 {{ color:white; font-size:1.6rem; margin:0; letter-spacing:-0.5px; }}
        .header p  {{ color:rgba(255,255,255,.8); font-size:.9rem; margin:.4rem 0 0; }}
        .body    {{ padding:2rem 2.5rem; }}
        .otp-box {{ background:#f0faf5; border:2px dashed #27AE60;
                   border-radius:12px; text-align:center;
                   padding:1.5rem; margin:1.5rem 0; }}
        .otp-code {{ font-size:2.6rem; font-weight:900; letter-spacing:10px;
                    color:#1a5e38; font-family:monospace; }}
        .otp-label {{ font-size:.78rem; color:#6b7280; margin-top:.4rem; }}
        .note    {{ background:#fff9e6; border-left:4px solid #f0ad4e;
                   border-radius:6px; padding:.8rem 1rem;
                   font-size:.82rem; color:#92400e; margin-top:1rem; }}
        .footer  {{ background:#f9fafb; padding:1rem 2.5rem;
                   text-align:center; font-size:.75rem; color:#9ca3af;
                   border-top:1px solid #e5e7eb; }}
        p {{ color:#374151; line-height:1.6; font-size:.92rem; }}
      </style>
    </head>
    <body>
      <div class="wrapper">
        <div class="header">
          <h1>🌿 WasteLens</h1>
          <p>Food Industry Waste Analysis System</p>
        </div>
        <div class="body">
          <p>{greeting}</p>
          <p>We received a request to reset your WasteLens password.
             Use the code below to continue. This code is valid for
             <strong>10 minutes</strong>.</p>

          <div class="otp-box">
            <div class="otp-code">{otp_code}</div>
            <div class="otp-label">One-Time Password (OTP)</div>
          </div>

          <div class="note">
            ⚠️ <strong>Do not share this code</strong> with anyone.
            WasteLens staff will never ask for your OTP.
          </div>

          <p style="margin-top:1.2rem">
            If you did not request a password reset, you can safely
            ignore this email — your password will not change.
          </p>
        </div>
        <div class="footer">
          WasteLens v1.0 &nbsp;|&nbsp; BIS 698 – Group 3 &nbsp;|&nbsp;
          This is an automated message, please do not reply.
        </div>
      </div>
    </body>
    </html>
    """

    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"]    = f"{cfg['sender_name']} <{cfg['sender_email']}>"
        msg["To"]      = to_email

        # plain-text fallback
        plain = (f"{greeting}\n\nYour WasteLens password reset code is: {otp_code}\n\n"
                 f"This code expires in 10 minutes.\n\n"
                 f"If you did not request this, ignore this email.")
        msg.attach(MIMEText(plain, "plain"))
        msg.attach(MIMEText(html_body, "html"))

        with smtplib.SMTP(cfg["smtp_host"], cfg["smtp_port"]) as server:
            server.ehlo()
            server.starttls()
            server.login(cfg["sender_email"], cfg["app_password"])
            server.sendmail(cfg["sender_email"], to_email, msg.as_string())

        return True, "sent"

    except smtplib.SMTPAuthenticationError:
        return False, "AUTH_FAILED"
    except smtplib.SMTPRecipientsRefused:
        return False, "INVALID_EMAIL"
    except Exception as e:
        return False, str(e)
