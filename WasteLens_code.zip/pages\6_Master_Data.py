# =============================================================
#  WasteLens – Master Data Management (Admin / Manager)
# =============================================================
import streamlit as st

st.set_page_config(
    page_title="Master Data | WasteLens",
    page_icon="⚙️",
    layout="wide",
)

import pandas as pd
from auth import require_role
from db import run_query, run_update
from utils import inject_css, render_sidebar

inject_css()
user = require_role(["Admin", "Manager"])
render_sidebar(user)

role = user["RoleName"]

st.title("⚙️ Master Data")
st.caption("Manage reference data: Items, Categories, Reasons" + (", and Branches" if role == "Admin" else ""))

if role == "Admin":
    tab_items, tab_cats, tab_reasons, tab_branches = st.tabs(
        ["🍗 Food Items", "🏷️ Waste Categories", "❓ Waste Reasons", "🏢 Branches"]
    )
else:
    tab_items, tab_cats, tab_reasons = st.tabs(
        ["🍗 Food Items", "🏷️ Waste Categories", "❓ Waste Reasons"]
    )
    tab_branches = None   # not shown for Manager


# ═══════════════════════════════════════════════════════════════
# TAB 1 – FOOD ITEMS
# ═══════════════════════════════════════════════════════════════
with tab_items:
    st.markdown("#### 🍗 Food Items")

    items = run_query(
        "SELECT ItemID, ItemName, Unit, CostPerUnit FROM Item ORDER BY ItemName"
    )

    left_col, right_col = st.columns([3, 2], gap="large")

    with left_col:
        if not items:
            st.info("No items yet. Add one using the form →")
        else:
            df_items = pd.DataFrame(items)
            df_items["CostPerUnit"] = df_items["CostPerUnit"].astype(float)
            df_items["🗑️ Delete"] = False

            edited_items = st.data_editor(
                df_items,
                use_container_width=True,
                hide_index=True,
                key="de_items",
                column_config={
                    "ItemID": st.column_config.NumberColumn("ID", disabled=True, width="small"),
                    "ItemName": st.column_config.TextColumn("Item Name", width="medium"),
                    "Unit": st.column_config.SelectboxColumn(
                        "Unit",
                        options=["kg", "pcs", "litre", "g", "ml", "box", "pack"],
                        width="small",
                    ),
                    "CostPerUnit": st.column_config.NumberColumn(
                        "Cost/Unit (RM)", min_value=0.0, step=0.01, format="RM %.2f", width="medium"
                    ),
                    "🗑️ Delete": st.column_config.CheckboxColumn("🗑️", width="small"),
                },
                disabled=["ItemID"],
            )

            if st.button("💾 Save Item Changes", key="save_items", use_container_width=True):
                saved = deleted = errors = 0
                for i, row in edited_items.iterrows():
                    orig = df_items.iloc[i]
                    if row["🗑️ Delete"]:
                        try:
                            run_update("DELETE FROM Item WHERE ItemID=%s", (int(row["ItemID"]),))
                            deleted += 1
                        except Exception as e:
                            st.error(f"Cannot delete **{row['ItemName']}** — it may be in use. ({e})")
                            errors += 1
                    elif (
                        row["ItemName"] != orig["ItemName"]
                        or row["Unit"] != orig["Unit"]
                        or abs(float(row["CostPerUnit"]) - float(orig["CostPerUnit"])) > 0.0001
                    ):
                        try:
                            run_update(
                                "UPDATE Item SET ItemName=%s, Unit=%s, CostPerUnit=%s WHERE ItemID=%s",
                                (row["ItemName"], row["Unit"], float(row["CostPerUnit"]), int(row["ItemID"])),
                            )
                            saved += 1
                        except Exception as e:
                            st.error(f"Cannot update **{row['ItemName']}** — name may already exist. ({e})")
                            errors += 1

                msgs = []
                if saved:   msgs.append(f"✅ {saved} item(s) updated")
                if deleted: msgs.append(f"🗑️ {deleted} item(s) deleted")
                if msgs:
                    st.success("  |  ".join(msgs))
                    st.rerun()
                elif not errors:
                    st.info("No changes detected.")

    with right_col:
        st.markdown("#### ➕ Add New Item")
        with st.form("add_item", clear_on_submit=True):
            i_name = st.text_input("Item Name *")
            i_unit = st.selectbox("Unit", ["kg", "pcs", "litre", "g", "ml", "box", "pack"])
            i_cpu  = st.number_input("Cost Per Unit (RM) *", min_value=0.0,
                                     step=0.01, format="%.2f")
            i_sub  = st.form_submit_button("➕ Add Item", use_container_width=True)
        if i_sub:
            if not i_name:
                st.error("Item name is required.")
            else:
                try:
                    run_update(
                        "INSERT INTO Item (ItemName, Unit, CostPerUnit) VALUES (%s,%s,%s)",
                        (i_name.strip(), i_unit, i_cpu),
                    )
                    st.success(f"✅ '{i_name}' added.")
                    st.rerun()
                except Exception as e:
                    st.error(f"Error: {e}")


# ═══════════════════════════════════════════════════════════════
# TAB 2 – WASTE CATEGORIES
# ═══════════════════════════════════════════════════════════════
with tab_cats:
    st.markdown("#### 🏷️ Waste Categories")

    cats = run_query(
        "SELECT WasteCategoryID, TypeName, Description FROM WasteCategory ORDER BY TypeName"
    )

    left_col2, right_col2 = st.columns([3, 2], gap="large")

    with left_col2:
        if not cats:
            st.info("No categories yet. Add one using the form →")
        else:
            df_cats = pd.DataFrame(cats)
            df_cats["Description"] = df_cats["Description"].fillna("")
            df_cats["🗑️ Delete"] = False

            edited_cats = st.data_editor(
                df_cats,
                use_container_width=True,
                hide_index=True,
                key="de_cats",
                column_config={
                    "WasteCategoryID": st.column_config.NumberColumn("ID", disabled=True, width="small"),
                    "TypeName": st.column_config.TextColumn("Category Name", width="medium"),
                    "Description": st.column_config.TextColumn("Description", width="large"),
                    "🗑️ Delete": st.column_config.CheckboxColumn("🗑️", width="small"),
                },
                disabled=["WasteCategoryID"],
            )

            if st.button("💾 Save Category Changes", key="save_cats", use_container_width=True):
                saved = deleted = errors = 0
                for i, row in edited_cats.iterrows():
                    orig = df_cats.iloc[i]
                    if row["🗑️ Delete"]:
                        try:
                            run_update(
                                "DELETE FROM WasteCategory WHERE WasteCategoryID=%s",
                                (int(row["WasteCategoryID"]),),
                            )
                            deleted += 1
                        except Exception as e:
                            st.error(f"Cannot delete **{row['TypeName']}** — it may be in use. ({e})")
                            errors += 1
                    elif row["TypeName"] != orig["TypeName"] or row["Description"] != orig["Description"]:
                        try:
                            run_update(
                                "UPDATE WasteCategory SET TypeName=%s, Description=%s WHERE WasteCategoryID=%s",
                                (row["TypeName"], row["Description"] or None, int(row["WasteCategoryID"])),
                            )
                            saved += 1
                        except Exception as e:
                            st.error(f"Cannot update **{row['TypeName']}** — name may already exist. ({e})")
                            errors += 1

                msgs = []
                if saved:   msgs.append(f"✅ {saved} category(ies) updated")
                if deleted: msgs.append(f"🗑️ {deleted} category(ies) deleted")
                if msgs:
                    st.success("  |  ".join(msgs))
                    st.rerun()
                elif not errors:
                    st.info("No changes detected.")

    with right_col2:
        st.markdown("#### ➕ Add New Category")
        with st.form("add_cat", clear_on_submit=True):
            c_name = st.text_input("Category Name *")
            c_desc = st.text_area("Description")
            c_sub  = st.form_submit_button("➕ Add Category", use_container_width=True)
        if c_sub:
            if not c_name:
                st.error("Category name is required.")
            else:
                try:
                    run_update(
                        "INSERT INTO WasteCategory (TypeName, Description) VALUES (%s,%s)",
                        (c_name.strip(), c_desc or None),
                    )
                    st.success(f"✅ Category '{c_name}' added.")
                    st.rerun()
                except Exception as e:
                    st.error(f"Error: {e}")


# ═══════════════════════════════════════════════════════════════
# TAB 3 – WASTE REASONS
# ═══════════════════════════════════════════════════════════════
with tab_reasons:
    st.markdown("#### ❓ Waste Reasons")

    reasons = run_query(
        "SELECT ReasonID, ReasonText, Description FROM WasteReason ORDER BY ReasonText"
    )

    left_col3, right_col3 = st.columns([3, 2], gap="large")

    with left_col3:
        if not reasons:
            st.info("No reasons yet. Add one using the form →")
        else:
            df_reasons = pd.DataFrame(reasons)
            df_reasons["Description"] = df_reasons["Description"].fillna("")
            df_reasons["🗑️ Delete"] = False

            edited_reasons = st.data_editor(
                df_reasons,
                use_container_width=True,
                hide_index=True,
                key="de_reasons",
                column_config={
                    "ReasonID": st.column_config.NumberColumn("ID", disabled=True, width="small"),
                    "ReasonText": st.column_config.TextColumn("Reason", width="medium"),
                    "Description": st.column_config.TextColumn("Description", width="large"),
                    "🗑️ Delete": st.column_config.CheckboxColumn("🗑️", width="small"),
                },
                disabled=["ReasonID"],
            )

            if st.button("💾 Save Reason Changes", key="save_reasons", use_container_width=True):
                saved = deleted = errors = 0
                for i, row in edited_reasons.iterrows():
                    orig = df_reasons.iloc[i]
                    if row["🗑️ Delete"]:
                        try:
                            run_update(
                                "DELETE FROM WasteReason WHERE ReasonID=%s",
                                (int(row["ReasonID"]),),
                            )
                            deleted += 1
                        except Exception as e:
                            st.error(f"Cannot delete **{row['ReasonText']}** — it may be in use. ({e})")
                            errors += 1
                    elif row["ReasonText"] != orig["ReasonText"] or row["Description"] != orig["Description"]:
                        try:
                            run_update(
                                "UPDATE WasteReason SET ReasonText=%s, Description=%s WHERE ReasonID=%s",
                                (row["ReasonText"], row["Description"] or None, int(row["ReasonID"])),
                            )
                            saved += 1
                        except Exception as e:
                            st.error(f"Cannot update **{row['ReasonText']}** — name may already exist. ({e})")
                            errors += 1

                msgs = []
                if saved:   msgs.append(f"✅ {saved} reason(s) updated")
                if deleted: msgs.append(f"🗑️ {deleted} reason(s) deleted")
                if msgs:
                    st.success("  |  ".join(msgs))
                    st.rerun()
                elif not errors:
                    st.info("No changes detected.")

    with right_col3:
        st.markdown("#### ➕ Add New Reason")
        with st.form("add_reason", clear_on_submit=True):
            r_text = st.text_input("Reason Text *")
            r_desc = st.text_area("Description")
            r_sub  = st.form_submit_button("➕ Add Reason", use_container_width=True)
        if r_sub:
            if not r_text:
                st.error("Reason text is required.")
            else:
                try:
                    run_update(
                        "INSERT INTO WasteReason (ReasonText, Description) VALUES (%s,%s)",
                        (r_text.strip(), r_desc or None),
                    )
                    st.success(f"✅ Reason '{r_text}' added.")
                    st.rerun()
                except Exception as e:
                    st.error(f"Error: {e}")


# ═══════════════════════════════════════════════════════════════
# TAB 4 – BRANCHES  (Admin only – tab not rendered for Manager)
# ═══════════════════════════════════════════════════════════════
if tab_branches is not None:
    with tab_branches:
        st.markdown("#### 🏢 Branches")

        branches = run_query(
            "SELECT BranchID, BranchName, Location, IsActive FROM Branch ORDER BY BranchName"
        )

        left_col4, right_col4 = st.columns([3, 2], gap="large")

        with left_col4:
            if not branches:
                st.info("No branches found. Add one using the form →")
            else:
                active_cnt   = sum(1 for b in branches if b["IsActive"])
                inactive_cnt = len(branches) - active_cnt
                m1, m2 = st.columns(2)
                m1.metric("🟢 Active Branches",   active_cnt)
                m2.metric("🔴 Inactive Branches", inactive_cnt)
                st.markdown("")

                df_br = pd.DataFrame(branches)
                df_br["IsActive"]    = df_br["IsActive"].astype(bool)
                df_br["🗑️ Delete"] = False

                edited_br = st.data_editor(
                    df_br,
                    use_container_width=True,
                    hide_index=True,
                    key="de_branches",
                    column_config={
                        "BranchID":   st.column_config.NumberColumn("ID", disabled=True, width="small"),
                        "BranchName": st.column_config.TextColumn("Branch Name", width="medium"),
                        "Location":   st.column_config.TextColumn("Location", width="large"),
                        "IsActive":   st.column_config.CheckboxColumn("Active?", width="small"),
                        "🗑️ Delete": st.column_config.CheckboxColumn("🗑️", width="small"),
                    },
                    disabled=["BranchID"],
                )

                if st.button("💾 Save Branch Changes", key="save_branches", use_container_width=True):
                    saved = deleted = errors = 0
                    for i, row in edited_br.iterrows():
                        orig = df_br.iloc[i]
                        if row["🗑️ Delete"]:
                            try:
                                run_update(
                                    "DELETE FROM Branch WHERE BranchID=%s",
                                    (int(row["BranchID"]),),
                                )
                                deleted += 1
                            except Exception as e:
                                st.error(f"Cannot delete **{row['BranchName']}** — it may be in use. ({e})")
                                errors += 1
                        elif (
                            row["BranchName"] != orig["BranchName"]
                            or row["Location"] != orig["Location"]
                            or bool(row["IsActive"]) != bool(orig["IsActive"])
                        ):
                            try:
                                run_update(
                                    "UPDATE Branch SET BranchName=%s, Location=%s, IsActive=%s WHERE BranchID=%s",
                                    (row["BranchName"], row["Location"],
                                     1 if row["IsActive"] else 0, int(row["BranchID"])),
                                )
                                saved += 1
                            except Exception as e:
                                st.error(f"Cannot update **{row['BranchName']}** — name may already exist. ({e})")
                                errors += 1

                    msgs = []
                    if saved:   msgs.append(f"✅ {saved} branch(es) updated")
                    if deleted: msgs.append(f"🗑️ {deleted} branch(es) deleted")
                    if msgs:
                        st.success("  |  ".join(msgs))
                        st.rerun()
                    elif not errors:
                        st.info("No changes detected.")

        with right_col4:
            st.markdown("#### ➕ Add New Branch")
            with st.form("add_branch", clear_on_submit=True):
                br_name = st.text_input("Branch Name *")
                br_loc  = st.text_input("Location *")
                br_sub  = st.form_submit_button("➕ Add Branch", use_container_width=True)
            if br_sub:
                if not br_name or not br_loc:
                    st.error("Branch name and location are required.")
                else:
                    try:
                        run_update(
                            "INSERT INTO Branch (BranchName, Location, IsActive) VALUES (%s,%s,1)",
                            (br_name.strip(), br_loc.strip()),
                        )
                        st.success(f"✅ Branch '{br_name}' added.")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Error: {e}")
