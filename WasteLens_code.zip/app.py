# =============================================================
#  WasteLens – Entry Point  (Login / Register / Forgot PW)
# =============================================================
import streamlit as st
import random

st.set_page_config(
    page_title="WasteLens",
    page_icon="🌿",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ── Global CSS ────────────────────────────────────────────────
st.markdown("""
<style>
  #MainMenu, footer { display: none !important; }
  header[data-testid="stHeader"] { display: none !important; }
  [data-testid="stSidebarNav"], [data-testid="stSidebar"] { display: none !important; }
  .block-container { padding: 0 !important; max-width: 100% !important; }
  section[data-testid="stAppViewContainer"] { background: #f0faf5 !important; }

  /* Primary submit buttons */
  [data-testid="stFormSubmitButton"] button {
    background: #27AE60 !important;
    color: white !important;
    border-radius: 9px !important;
    font-weight: 700 !important;
    font-size: 1rem !important;
    padding: 0.7rem !important;
    width: 100% !important;
    border: none !important;
    transition: all .2s !important;
    margin-top: 0.5rem !important;
  }
  [data-testid="stFormSubmitButton"] button:hover {
    background: #1e8449 !important;
    transform: translateY(-1px) !important;
    box-shadow: 0 4px 14px rgba(39,174,96,.35) !important;
  }

  /* Inputs */
  [data-testid="stTextInput"] input {
    border-radius: 8px !important;
    padding: 0.55rem 0.75rem !important;
    font-size: 0.95rem !important;
  }

  /* Strength row */
  .strength-item { font-size: 0.74rem; text-align: center; padding: 2px; }

  /* Nav link buttons */
  [data-testid="stButton"] button {
    background: transparent !important;
    border: none !important;
    color: #27AE60 !important;
    font-weight: 600 !important;
    padding: 0 !important;
    font-size: 0.88rem !important;
    cursor: pointer !important;
    text-decoration: underline !important;
    text-underline-offset: 2px !important;
  }
  [data-testid="stButton"] button:hover {
    color: #1e8449 !important;
    background: transparent !important;
    box-shadow: none !important;
    transform: none !important;
  }
</style>
""", unsafe_allow_html=True)

# ── Redirect if already logged in ─────────────────────────────
if "user" in st.session_state:
    st.switch_page("pages/1_Dashboard.py")

# ── View state: "login" | "register" | "forgot_email" | "forgot_otp"
if "auth_view" not in st.session_state:
    st.session_state["auth_view"] = "login"

# ── Password helpers ──────────────────────────────────────────
def check_password_strength(pwd: str):
    issues = []
    if len(pwd) < 8:                                              issues.append("At least 8 characters")
    if not any(c.isupper() for c in pwd):                        issues.append("One uppercase letter")
    if not any(c.islower() for c in pwd):                        issues.append("One lowercase letter")
    if not any(c.isdigit() for c in pwd):                        issues.append("One number")
    if not any(c in "!@#$%^&*()_+-=[]{}|;':\",./<>?" for c in pwd): issues.append("One special character")
    return len(issues) == 0, issues

def show_password_rules(pwd: str):
    checks = [
        (len(pwd) >= 8,                                              "8+ chars"),
        (any(c.isupper() for c in pwd),                             "Uppercase"),
        (any(c.islower() for c in pwd),                             "Lowercase"),
        (any(c.isdigit() for c in pwd),                             "Number"),
        (any(c in "!@#$%^&*()_+-=[]{}|;':\",./<>?" for c in pwd),  "Symbol"),
    ]
    cols = st.columns(5)
    for col, (ok, label) in zip(cols, checks):
        col.markdown(
            f"<div class='strength-item' style='color:{'#27AE60' if ok else '#bbb'};"
            f"font-weight:{'700' if ok else '400'}'>{'✅' if ok else '⬜'} {label}</div>",
            unsafe_allow_html=True,
        )

# ── Seed DB passwords silently ─────────────────────────────────
try:
    from db import init_passwords
    init_passwords()
except Exception:
    pass

# ══════════════════════════════════════════════════════════════
#  LAYOUT  – Left branding panel  |  Right form
# ══════════════════════════════════════════════════════════════
left, right = st.columns([4, 6], gap="small")

# ─── LEFT BRANDING PANEL ─────────────────────────────────────
with left:
    st.markdown("""
    <div style="
        background: linear-gradient(150deg,#1a5e38 0%,#27AE60 60%,#52c47d 100%);
        border-radius: 20px; padding: 3.5rem 2.5rem; color: white;
        min-height: 92vh; display: flex; flex-direction: column;
        justify-content: center; margin: 2vh 0 2vh 2vw;
        box-shadow: 0 8px 32px rgba(39,174,96,.25);
    ">
      <div style="font-size:4rem;margin-bottom:.8rem">🌿</div>
      <h1 style="font-size:2.6rem;font-weight:800;margin:0 0 .4rem;color:white;
                 letter-spacing:-1px">WasteLens</h1>
      <p style="font-size:1.05rem;opacity:.85;margin-bottom:2.5rem;line-height:1.6">
        Food Industry Waste<br>Analysis System
      </p>
      <div style="border-top:1px solid rgba(255,255,255,.25);padding-top:1.8rem;
                  display:flex;flex-direction:column;gap:1.1rem">
        <div style="display:flex;align-items:center;gap:.9rem">
          <span style="font-size:1.3rem;background:rgba(255,255,255,.15);
                border-radius:10px;padding:.35rem .55rem">📊</span>
          <span style="font-size:.92rem">Real-time waste tracking &amp; analytics</span>
        </div>
        <div style="display:flex;align-items:center;gap:.9rem">
          <span style="font-size:1.3rem;background:rgba(255,255,255,.15);
                border-radius:10px;padding:.35rem .55rem">🏢</span>
          <span style="font-size:.92rem">Multi-branch management</span>
        </div>
        <div style="display:flex;align-items:center;gap:.9rem">
          <span style="font-size:1.3rem;background:rgba(255,255,255,.15);
                border-radius:10px;padding:.35rem .55rem">💰</span>
          <span style="font-size:.92rem">Cost &amp; quantity insights</span>
        </div>
        <div style="display:flex;align-items:center;gap:.9rem">
          <span style="font-size:1.3rem;background:rgba(255,255,255,.15);
                border-radius:10px;padding:.35rem .55rem">📈</span>
          <span style="font-size:.92rem">Reports &amp; trend analysis</span>
        </div>
      </div>
      <div style="margin-top:auto;padding-top:2rem;
                  border-top:1px solid rgba(255,255,255,.2);
                  font-size:.78rem;opacity:.65">
        BIS 698 – Group 3 &nbsp;|&nbsp; Capstone Project 2026
      </div>
    </div>
    """, unsafe_allow_html=True)

# ─── RIGHT FORM AREA ─────────────────────────────────────────
with right:
    _, form_col, _ = st.columns([1, 8, 1])
    with form_col:
        view = st.session_state["auth_view"]

        # ══════════════════════════════════════════════════════
        #  VIEW: LOGIN
        # ══════════════════════════════════════════════════════
        if view == "login":
            st.markdown("""
            <div style="padding:4vh 0 1.5rem">
              <h2 style="font-size:1.8rem;font-weight:800;color:#1a2e1a;margin-bottom:.3rem">
                Sign in to WasteLens
              </h2>
              <p style="color:#6b7280;font-size:.92rem;margin-bottom:1.8rem">
                Enter your credentials to access your dashboard
              </p>
            </div>
            """, unsafe_allow_html=True)

            with st.form("login_form"):
                email    = st.text_input("Email address", placeholder="you@wastelens.com")
                password = st.text_input("Password", type="password", placeholder="••••••••")
                submitted = st.form_submit_button("Sign In →", use_container_width=True)

            if submitted:
                if not email or not password:
                    st.error("Please enter both email and password.")
                else:
                    try:
                        from auth import login
                        user, err = login(email.strip().lower(), password)
                        if err:
                            st.error(f"❌ {err}")
                        else:
                            st.session_state["user"] = user
                            st.success("✅ Login successful! Redirecting…")
                            st.switch_page("pages/1_Dashboard.py")
                    except ConnectionError as ce:
                        st.error(f"⚠️ Cannot connect to database. Check `config.py`.\n\n`{ce}`")

            # ── Nav links ──────────────────────────────────────
            st.markdown(
                "<hr style='border:none;border-top:1px solid #e5e7eb;margin:1.2rem 0'>",
                unsafe_allow_html=True,
            )
            lnk1, lnk2 = st.columns(2)
            with lnk1:
                st.markdown(
                    "<span style='color:#6b7280;font-size:.88rem'>Forgot your password? </span>",
                    unsafe_allow_html=True,
                )
                if st.button("Reset it here", key="goto_forgot"):
                    st.session_state["auth_view"] = "forgot_email"
                    st.rerun()
            with lnk2:
                st.markdown(
                    "<span style='color:#6b7280;font-size:.88rem'>New user? </span>",
                    unsafe_allow_html=True,
                )
                if st.button("Create an account", key="goto_register"):
                    st.session_state["auth_view"] = "register"
                    st.rerun()


        # ══════════════════════════════════════════════════════
        #  VIEW: REGISTER
        # ══════════════════════════════════════════════════════
        elif view == "register":
            st.markdown("""
            <div style="padding:4vh 0 1rem">
              <h2 style="font-size:1.8rem;font-weight:800;color:#1a2e1a;margin-bottom:.3rem">
                Create your account
              </h2>
              <p style="color:#6b7280;font-size:.92rem;margin-bottom:1.5rem">
                Fill in your details to register. An admin will approve your account.
              </p>
            </div>
            """, unsafe_allow_html=True)

            try:
                from db import run_query
                branches = run_query(
                    "SELECT BranchID, BranchName FROM Branch WHERE IsActive=1 ORDER BY BranchName"
                )
                branch_map = {b["BranchName"]: b["BranchID"] for b in branches} if branches else {}
            except Exception:
                branch_map = {}

            rn1, rn2 = st.columns(2)
            with rn1:
                r_first = st.text_input("First Name *", placeholder="Jane",  key="reg_first")
            with rn2:
                r_last  = st.text_input("Last Name *",  placeholder="Doe",   key="reg_last")

            r_email      = st.text_input("Email address *", placeholder="jane@example.com", key="r_email")
            r_branch_sel = st.selectbox(
                "Assigned Branch *", options=list(branch_map.keys()),
                help="You will be assigned to this branch as Staff.", key="reg_branch",
            )
            rp1, rp2 = st.columns(2)
            with rp1:
                r_pass    = st.text_input("Password *", type="password",
                                          placeholder="Min 8 chars…", key="r_pass")
            with rp2:
                r_confirm = st.text_input("Confirm Password *", type="password",
                                          placeholder="Repeat password", key="r_confirm")
            if r_pass:
                show_password_rules(r_pass)

            with st.form("register_form"):
                st.caption("All fields above are required — review then submit.")
                reg_sub = st.form_submit_button("Create Account →", use_container_width=True)

            if reg_sub:
                r_name = f"{r_first.strip()} {r_last.strip()}".strip()
                pwd_ok, pwd_issues = check_password_strength(r_pass)
                if not all([r_first, r_last, r_email, r_branch_sel, r_pass, r_confirm]):
                    st.error("Please fill in all fields.")
                elif r_pass != r_confirm:
                    st.error("❌ Passwords do not match.")
                elif not pwd_ok:
                    st.error("❌ Password too weak:\n- " + "\n- ".join(pwd_issues))
                else:
                    try:
                        from auth import register
                        ok, msg = register(
                            r_name, r_email.strip().lower(), r_pass,
                            branch_map.get(r_branch_sel, 1),
                        )
                        if ok:
                            st.success(f"✅ {msg}")
                            st.session_state["auth_view"] = "login"
                            st.rerun()
                        else:
                            st.error(f"❌ {msg}")
                    except ConnectionError as ce:
                        st.error(f"⚠️ Database error: {ce}")

            st.markdown(
                "<hr style='border:none;border-top:1px solid #e5e7eb;margin:1.2rem 0'>",
                unsafe_allow_html=True,
            )
            st.markdown(
                "<span style='color:#6b7280;font-size:.88rem'>Already have an account? </span>",
                unsafe_allow_html=True,
            )
            if st.button("Sign in here", key="goto_login_from_reg"):
                st.session_state["auth_view"] = "login"
                st.rerun()

        # ══════════════════════════════════════════════════════
        #  VIEW: FORGOT PASSWORD – STEP 1 (enter email)
        # ══════════════════════════════════════════════════════
        elif view == "forgot_email":
            st.markdown("""
            <div style="padding:4vh 0 1rem">
              <h2 style="font-size:1.8rem;font-weight:800;color:#1a2e1a;margin-bottom:.3rem">
                Reset your password
              </h2>
              <p style="color:#6b7280;font-size:.92rem;margin-bottom:1.5rem">
                Enter your registered email address and we'll send you a
                one-time verification code.
              </p>
            </div>
            """, unsafe_allow_html=True)

            with st.form("fp_email_form"):
                fp_email_input = st.text_input(
                    "Registered Email Address", placeholder="you@wastelens.com",
                )
                send_btn = st.form_submit_button("Send OTP →", use_container_width=True)

            if send_btn:
                if not fp_email_input.strip():
                    st.error("Please enter your email address.")
                else:
                    try:
                        from db import run_query as _rq
                        row = _rq(
                            "SELECT UserID, UserName FROM User WHERE Email=%s AND IsActive=1 LIMIT 1",
                            (fp_email_input.strip().lower(),),
                        )
                        if not row:
                            st.error("❌ No active account found with that email address.")
                        else:
                            otp_code  = str(random.randint(100000, 999999))
                            user_name = row[0]["UserName"]

                            # ── Try to send real email ──────────
                            from email_utils import send_otp_email
                            sent, msg = send_otp_email(
                                fp_email_input.strip().lower(), otp_code, user_name
                            )

                            import time
                            st.session_state["fp_otp"]        = otp_code
                            st.session_state["fp_otp_expiry"] = time.time() + 600  # 10 min
                            st.session_state["fp_email"]      = fp_email_input.strip().lower()
                            st.session_state["fp_email_sent"] = sent
                            st.session_state["auth_view"]    = "forgot_otp"

                            if sent:
                                st.session_state["fp_send_msg"] = "real"
                            elif msg == "EMAIL_NOT_CONFIGURED":
                                st.session_state["fp_send_msg"] = "demo"
                            else:
                                st.session_state["fp_send_msg"] = f"error:{msg}"

                            st.rerun()
                    except Exception as e:
                        st.error(f"⚠️ Error: {e}")

            st.markdown(
                "<hr style='border:none;border-top:1px solid #e5e7eb;margin:1.2rem 0'>",
                unsafe_allow_html=True,
            )
            st.markdown(
                "<span style='color:#6b7280;font-size:.88rem'>Remember your password? </span>",
                unsafe_allow_html=True,
            )
            if st.button("Back to Sign In", key="back_to_login_fp"):
                st.session_state["auth_view"] = "login"
                st.rerun()

        # ══════════════════════════════════════════════════════
        #  VIEW: FORGOT PASSWORD – STEP 2 (verify OTP + reset)
        # ══════════════════════════════════════════════════════
        elif view == "forgot_otp":
            fp_email_display = st.session_state.get("fp_email", "")
            otp_correct      = st.session_state.get("fp_otp", "")

            send_msg = st.session_state.get("fp_send_msg", "demo")

            st.markdown(f"""
            <div style="padding:4vh 0 1rem">
              <h2 style="font-size:1.8rem;font-weight:800;color:#1a2e1a;margin-bottom:.3rem">
                Verify &amp; Reset
              </h2>
              <p style="color:#6b7280;font-size:.92rem;margin-bottom:.5rem">
                Enter the 6-digit code to reset your password.
              </p>
            </div>
            """, unsafe_allow_html=True)

            # ── Show delivery status banner ──────────────────────
            if send_msg == "real":
                st.success(
                    f"📧 OTP sent to **{fp_email_display}** — check your inbox "
                    f"(and spam folder if not seen within 1 minute)."
                )
            elif send_msg == "demo":
                st.info(
                    f"🧪 **Demo Mode** — email not configured yet.\n\n"
                    f"Your OTP code is: **`{otp_correct}`**\n\n"
                    f"*(Add your Gmail App Password in `config.py` to enable real emails)*"
                )
            elif send_msg.startswith("error:"):
                err_detail = send_msg.replace("error:", "")
                st.warning(
                    f"⚠️ Could not send email ({err_detail}).\n\n"
                    f"OTP code: **`{otp_correct}`**"
                )

            otp_entered = st.text_input(
                "Enter 6-digit OTP", placeholder="e.g. 482910",
                max_chars=6, key="fp_otp_input",
            )
            fp1, fp2 = st.columns(2)
            with fp1:
                fp_new  = st.text_input("New Password", type="password",
                                        placeholder="Min 8 chars…", key="fp_new")
            with fp2:
                fp_conf = st.text_input("Confirm New Password", type="password",
                                        placeholder="Repeat", key="fp_conf")
            if fp_new:
                show_password_rules(fp_new)

            with st.form("fp_reset_form"):
                reset_btn = st.form_submit_button("Reset Password →", use_container_width=True)

            if reset_btn:
                import time
                fp_ok, fp_issues = check_password_strength(fp_new)
                otp_expiry = st.session_state.get("fp_otp_expiry", 0)
                if not otp_entered.strip():
                    st.error("Please enter the OTP code.")
                elif time.time() > otp_expiry:
                    st.error("⏰ OTP has expired (10 min limit). Please request a new one.")
                    for k in ("fp_otp", "fp_email", "fp_otp_expiry", "fp_send_msg"):
                        st.session_state.pop(k, None)
                    st.session_state["auth_view"] = "forgot_email"
                    st.rerun()
                elif otp_entered.strip() != otp_correct:
                    st.error("❌ Incorrect OTP. Please check and try again.")
                elif not fp_new or not fp_conf:
                    st.error("Please enter and confirm your new password.")
                elif fp_new != fp_conf:
                    st.error("❌ Passwords do not match.")
                elif not fp_ok:
                    st.error("❌ Password too weak:\n- " + "\n- ".join(fp_issues))
                else:
                    try:
                        from db import run_query as _rq3, run_update as _ru
                        from auth import hash_password
                        uid_row = _rq3(
                            "SELECT UserID FROM User WHERE Email=%s AND IsActive=1 LIMIT 1",
                            (fp_email_display,),
                        )
                        if uid_row:
                            _ru("UPDATE User SET Password=%s WHERE UserID=%s",
                                (hash_password(fp_new), uid_row[0]["UserID"]))
                            for k in ("fp_otp", "fp_email"):
                                st.session_state.pop(k, None)
                            st.session_state["auth_view"] = "login"
                            st.success("✅ Password reset! You can now sign in.")
                            st.rerun()
                        else:
                            st.error("Account not found.")
                    except Exception as e:
                        st.error(f"⚠️ Error: {e}")

            st.markdown(
                "<hr style='border:none;border-top:1px solid #e5e7eb;margin:1.2rem 0'>",
                unsafe_allow_html=True,
            )
            st.markdown(
                "<span style='color:#6b7280;font-size:.88rem'>Wrong email? </span>",
                unsafe_allow_html=True,
            )
            if st.button("Try a different email", key="back_to_fp_email"):
                for k in ("fp_otp", "fp_email"):
                    st.session_state.pop(k, None)
                st.session_state["auth_view"] = "forgot_email"
                st.rerun()

        # ── Footer ─────────────────────────────────────────────
        st.markdown(
            "<div style='text-align:center;color:#aaa;font-size:.74rem;padding-top:2rem'>"
            "WasteLens v1.0 &nbsp;|&nbsp; BIS 698 – Group 3</div>",
            unsafe_allow_html=True,
        )
