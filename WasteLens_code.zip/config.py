# =============================================================
#  WasteLens – Configuration
#  Edit DB_CONFIG to match your MySQL setup
# =============================================================

DB_CONFIG = {
    "host": "141.209.241.91 ",
    "port": 3306,
    "database": "Sp2026BIS698ThuG3s",
    "user": "Sp2026BIS698ThuG3",
    "password": "warm",          # <── set your MySQL root password here
}

# Default passwords injected on first run (replaces SQL placeholder hashes)
DEFAULT_PASSWORDS = {
    "admin@wastelens.com":        "Admin@123",
    "manager@wastelens.com":      "Manager@123",
    "staff@wastelens.com":        "Staff@123",
    "dhanalakshmikm25@gmail.com": "Dhana@123",
    "kannu1d@cmich.edu":          "123456",
    "chiri1s@cmich.edu":          "Chiri@123",
}

APP_TITLE   = "WasteLens"
APP_ICON    = "🌿"
PRIMARY_CLR = "#27AE60"

# ── Email / SMTP (for OTP password reset) ─────────────────────
# Step 1: Enable 2-Step Verification on your Gmail account
# Step 2: Go to https://myaccount.google.com/apppasswords
# Step 3: Create an App Password → copy the 16-char code below
EMAIL_CONFIG = {
    "smtp_host":   "smtp.gmail.com",
    "smtp_port":   587,
    "sender_email": "dhanalakshmikm25@gmail.com",   # <── your Gmail
    "app_password": "soal ypde vhvs mkie",                              # <── 16-char App Password
    "sender_name":  "WasteLens",
}
