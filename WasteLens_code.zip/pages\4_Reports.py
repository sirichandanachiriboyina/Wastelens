# =============================================================
#  WasteLens – Reports & Analytics  (Manager / Admin)
#  Enriched with 10+ chart types
# =============================================================
import streamlit as st

st.set_page_config(
    page_title="Reports | WasteLens",
    page_icon="📈",
    layout="wide",
)

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import date, timedelta
from auth import require_role, branch_filter_sql
from db import run_query
from utils import inject_css, render_sidebar

inject_css()
user = require_role(["Admin", "Manager"])
render_sidebar(user)

bf = branch_filter_sql(user)

st.title("📈 Reports & Analytics")
st.caption("Comprehensive waste intelligence for management decisions")

# ══ FILTERS (always visible, collapsed by default) ════════════
rc1, rc2, rc3, rc4 = st.columns(4)
with rc1:
    rpt_from = st.date_input("From", value=date(2025, 3, 1))
with rc2:
    rpt_to   = st.date_input("To",   value=date.today())
with rc3:
    if user["RoleName"] == "Admin":
        all_br   = run_query("SELECT BranchID, BranchName FROM Branch WHERE IsActive=1 ORDER BY BranchName")
        br_opts  = ["All Branches"] + [b["BranchName"] for b in all_br]
        sel_br   = st.selectbox("Branch", br_opts)
        if sel_br != "All Branches":
            bid      = next(b["BranchID"] for b in all_br if b["BranchName"] == sel_br)
            extra_bf = f" AND wl.BranchID = {bid}"
        else:
            extra_bf = bf
    else:
        extra_bf = bf
        st.info("Viewing your accessible branches")
with rc4:
    metric_type = st.radio("Primary Metric", ["Quantity (kg)", "Cost (RM)"], horizontal=True)
    y_col    = "Qty_kg"   if metric_type == "Quantity (kg)" else "Cost_RM"
    y_label  = "Qty (kg)" if metric_type == "Quantity (kg)" else "Cost (RM)"

date_clause = " AND DATE(wl.WasteDateTime) BETWEEN %(fd)s AND %(td)s"
params = {"fd": str(rpt_from), "td": str(rpt_to)}

# ══ SUMMARY KPI CARDS (update immediately when filter changes) ═
summary = run_query(
    f"""SELECT COUNT(*)                          AS Entries,
               ROUND(SUM(wl.Quantity),2)          AS Qty_kg,
               ROUND(SUM(wl.EstimatedCost),2)     AS Cost_RM,
               ROUND(AVG(wl.Quantity),3)           AS Avg_Qty,
               ROUND(AVG(wl.EstimatedCost),2)      AS Avg_Cost,
               COUNT(DISTINCT wl.BranchID)         AS Branches,
               COUNT(DISTINCT wl.ItemID)           AS UniqueItems,
               COUNT(DISTINCT wl.WasteCategoryID)  AS Categories
        FROM WasteLog wl WHERE 1=1 {extra_bf} {date_clause}""",
    params,
)
if summary and summary[0]["Entries"]:
    r = summary[0]
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Total Entries",   f"{r['Entries']:,}")
    m2.metric("Total Waste",     f"{float(r['Qty_kg'] or 0):,.2f} kg")
    m3.metric("Total Cost",      f"RM {float(r['Cost_RM'] or 0):,.2f}")
    m4.metric("Branches Active", f"{r['Branches']}")
    m5, m6, m7, m8 = st.columns(4)
    m5.metric("Avg Qty / Entry",  f"{float(r['Avg_Qty'] or 0):,.3f} kg")
    m6.metric("Avg Cost / Entry", f"RM {float(r['Avg_Cost'] or 0):,.2f}")
    m7.metric("Unique Items",     f"{r['UniqueItems']}")
    m8.metric("Categories Used",  f"{r['Categories']}")
else:
    st.info("No data found for the selected filters.")
st.markdown("---")

# ══ TABS ══════════════════════════════════════════════════════
tabs = st.tabs([
    "📊 Overview", "📦 Items", "🏷️ Categories",
    "🏢 Branches", "💾 Export"
])

# ─────────────────────────────────────────────────────────────
# TAB 1 – OVERVIEW
# ─────────────────────────────────────────────────────────────
with tabs[0]:
    c_left, c_right = st.columns(2)

    # Top 10 items by cost – horizontal bar
    with c_left:
        top_items = run_query(
            f"""SELECT i.ItemName,
                       ROUND(SUM(wl.Quantity),2)      AS Qty_kg,
                       ROUND(SUM(wl.EstimatedCost),2) AS Cost_RM
                FROM WasteLog wl JOIN Item i ON i.ItemID=wl.ItemID
                WHERE 1=1 {extra_bf} {date_clause}
                GROUP BY i.ItemName ORDER BY Cost_RM DESC LIMIT 10""",
            params,
        )
        if top_items:
            df_ti = pd.DataFrame(top_items)
            fig = px.bar(df_ti, x=y_col, y="ItemName", orientation="h",
                         color=y_col, text=y_col,
                         color_continuous_scale=["#a8d5b5","#27AE60","#1a6e3c"],
                         title=f"🏆 Top 10 Items by {y_label}",
                         labels={"ItemName":"Item", y_col: y_label})
            fig.update_traces(texttemplate="%{text:.2f}", textposition="outside")
            fig.update_layout(plot_bgcolor="white", paper_bgcolor="white",
                              coloraxis_showscale=False,
                              yaxis=dict(autorange="reversed"),
                              margin=dict(t=40,b=10))
            st.plotly_chart(fig, use_container_width=True)

    # Waste by reason – pie
    with c_right:
        reason_data = run_query(
            f"""SELECT wr.ReasonText AS Reason,
                       ROUND(SUM(wl.Quantity),2)      AS Qty_kg,
                       ROUND(SUM(wl.EstimatedCost),2) AS Cost_RM
                FROM WasteLog wl JOIN WasteReason wr ON wr.ReasonID=wl.ReasonID
                WHERE 1=1 {extra_bf} {date_clause}
                GROUP BY wr.ReasonText ORDER BY {y_col} DESC LIMIT 8""",
            params,
        )
        if reason_data:
            df_rr = pd.DataFrame(reason_data)
            fig2 = px.pie(df_rr, names="Reason", values=y_col, hole=0.4,
                          color_discrete_sequence=px.colors.qualitative.Pastel,
                          title=f"🎯 Top Reasons by {y_label}")
            fig2.update_traces(textinfo="percent+label", textposition="inside",
                               insidetextorientation="radial")
            fig2.update_layout(showlegend=True,
                               legend=dict(orientation="h", y=-0.2),
                               paper_bgcolor="white",
                               margin=dict(t=50, b=60, l=20, r=20))
            st.plotly_chart(fig2, use_container_width=True)

    # Month-over-Month stacked bar by category
    st.markdown("#### 📅 Month-over-Month Waste by Category")
    mom_data = run_query(
        f"""SELECT DATE_FORMAT(wl.WasteDateTime,'%Y-%m')  AS Month,
                   DATE_FORMAT(wl.WasteDateTime,'%b %Y')  AS MonthLabel,
                   wc.TypeName                             AS Category,
                   ROUND(SUM(wl.Quantity),2)               AS Qty_kg,
                   ROUND(SUM(wl.EstimatedCost),2)          AS Cost_RM
            FROM WasteLog wl
            JOIN WasteCategory wc ON wc.WasteCategoryID = wl.WasteCategoryID
            WHERE 1=1 {extra_bf}
              AND wl.WasteDateTime >= DATE_FORMAT(
                      CURDATE() - INTERVAL 5 MONTH, '%Y-%m-01')
            GROUP BY Month, MonthLabel, wc.TypeName
            ORDER BY Month, Qty_kg DESC""",
        None,
    )
    if mom_data:
        df_mom = pd.DataFrame(mom_data)
        df_mom["Qty_kg"]   = pd.to_numeric(df_mom["Qty_kg"],   errors="coerce").fillna(0)
        df_mom["Cost_RM"]  = pd.to_numeric(df_mom["Cost_RM"],  errors="coerce").fillna(0)
        fig_mom = px.bar(
            df_mom, x="MonthLabel", y=y_col, color="Category",
            barmode="stack",
            color_discrete_sequence=px.colors.qualitative.Set2,
            labels={"MonthLabel": "Month", y_col: y_label},
            title=f"Month-over-Month {y_label} by Waste Category",
            text_auto=False,
        )
        fig_mom.update_layout(
            plot_bgcolor="white", paper_bgcolor="white",
            xaxis=dict(tickangle=-20),
            legend=dict(orientation="h", y=-0.25),
            margin=dict(t=50, b=20),
            hovermode="x unified",
        )
        st.plotly_chart(fig_mom, use_container_width=True)

# ─────────────────────────────────────────────────────────────
# TAB 2 – ITEMS
# ─────────────────────────────────────────────────────────────
with tabs[1]:
    item_data = run_query(
        f"""SELECT i.ItemName, i.Unit,
                   COUNT(*)                         AS Entries,
                   ROUND(SUM(wl.Quantity),3)         AS Qty_kg,
                   ROUND(SUM(wl.EstimatedCost),2)    AS Cost_RM,
                   ROUND(AVG(wl.Quantity),3)          AS Avg_Qty,
                   ROUND(AVG(wl.EstimatedCost),2)     AS Avg_Cost
            FROM WasteLog wl JOIN Item i ON i.ItemID=wl.ItemID
            WHERE 1=1 {extra_bf} {date_clause}
            GROUP BY i.ItemName, i.Unit ORDER BY Cost_RM DESC""",
        params,
    )
    if item_data:
        df_i = pd.DataFrame(item_data)
        col_a, col_b = st.columns([3,2])
        with col_a:
            st.dataframe(df_i, use_container_width=True, hide_index=True)
        with col_b:
            fig_tm = px.treemap(df_i, path=["ItemName"], values=y_col,
                                color=y_col,
                                color_continuous_scale=["#d5f5e3","#27AE60","#1a6e3c"],
                                title=f"Treemap – {y_label} by Item")
            fig_tm.update_layout(margin=dict(t=30,b=5))
            st.plotly_chart(fig_tm, use_container_width=True)

        # Funnel: top items by quantity
        st.markdown("#### 🔽 Waste Volume Funnel (Top 10 Items)")
        df_funnel = df_i.head(10).sort_values("Qty_kg")
        fig_f = go.Figure(go.Funnel(
            y=df_funnel["ItemName"], x=df_funnel["Qty_kg"],
            textinfo="value+percent total",
            marker=dict(color="#27AE60"),
        ))
        fig_f.update_layout(paper_bgcolor="white", margin=dict(t=10,b=10))
        st.plotly_chart(fig_f, use_container_width=True)

# ─────────────────────────────────────────────────────────────
# TAB 3 – CATEGORIES
# ─────────────────────────────────────────────────────────────
with tabs[2]:
    cat_data = run_query(
        f"""SELECT wc.TypeName AS Category,
                   COUNT(*)                         AS Entries,
                   ROUND(SUM(wl.Quantity),2)         AS Qty_kg,
                   ROUND(SUM(wl.EstimatedCost),2)    AS Cost_RM,
                   ROUND(100.0*SUM(wl.Quantity)/
                         SUM(SUM(wl.Quantity)) OVER(),1) AS Pct_Qty
            FROM WasteLog wl
            JOIN WasteCategory wc ON wc.WasteCategoryID=wl.WasteCategoryID
            WHERE 1=1 {extra_bf} {date_clause}
            GROUP BY wc.TypeName ORDER BY Qty_kg DESC""",
        params,
    )
    if cat_data:
        df_cat = pd.DataFrame(cat_data)
        col_a, col_b = st.columns([2,3])
        with col_a:
            fig_pie = px.pie(df_cat, names="Category", values=y_col, hole=0.4,
                             color_discrete_sequence=px.colors.qualitative.Set2,
                             title=f"Category Share – {y_label}")
            fig_pie.update_traces(textinfo="percent+label", textposition="inside",
                                  insidetextorientation="radial")
            fig_pie.update_layout(showlegend=True,
                                  legend=dict(orientation="h", y=-0.2),
                                  paper_bgcolor="white",
                                  margin=dict(t=50, b=60, l=20, r=20))
            st.plotly_chart(fig_pie, use_container_width=True)
        with col_b:
            st.dataframe(df_cat, use_container_width=True, hide_index=True)

        # Stacked bar: category by branch
        st.markdown("#### 📊 Category Distribution by Branch")
        stacked = run_query(
            f"""SELECT b.BranchName AS Branch,
                       wc.TypeName  AS Category,
                       ROUND(SUM(wl.Quantity),2)      AS Qty_kg,
                       ROUND(SUM(wl.EstimatedCost),2) AS Cost_RM
                FROM WasteLog wl
                JOIN WasteCategory wc ON wc.WasteCategoryID=wl.WasteCategoryID
                JOIN Branch b ON b.BranchID=wl.BranchID
                WHERE 1=1 {extra_bf} {date_clause}
                GROUP BY b.BranchName, wc.TypeName
                ORDER BY Branch, Qty_kg DESC""",
            params,
        )
        if stacked:
            df_st = pd.DataFrame(stacked)
            fig_st = px.bar(df_st, x="Branch", y=y_col, color="Category",
                            barmode="stack",
                            color_discrete_sequence=px.colors.qualitative.Set2,
                            labels={"Branch":"Branch", y_col: y_label},
                            title=f"Stacked {y_label} by Branch & Category")
            fig_st.update_layout(plot_bgcolor="white", paper_bgcolor="white",
                                 legend=dict(orientation="h",y=-0.3),
                                 margin=dict(t=40,b=10))
            st.plotly_chart(fig_st, use_container_width=True)

# ─────────────────────────────────────────────────────────────
# TAB 4 – BRANCHES
# ─────────────────────────────────────────────────────────────
with tabs[3]:
    branch_data = run_query(
        f"""SELECT b.BranchName AS Branch,
                   COUNT(wl.WasteLogID)              AS Entries,
                   ROUND(SUM(wl.Quantity),2)          AS Qty_kg,
                   ROUND(SUM(wl.EstimatedCost),2)     AS Cost_RM,
                   ROUND(AVG(wl.EstimatedCost),2)     AS Avg_Cost,
                   COUNT(DISTINCT wl.ItemID)           AS UniqueItems
            FROM   Branch b
            LEFT JOIN WasteLog wl ON wl.BranchID=b.BranchID
                  AND DATE(wl.WasteDateTime) BETWEEN %(fd)s AND %(td)s
            WHERE  b.IsActive=1
            GROUP  BY b.BranchID, b.BranchName
            ORDER  BY Qty_kg DESC""",
        params,
    )
    if branch_data:
        df_br = pd.DataFrame(branch_data)

        # grouped bar
        fig5 = go.Figure()
        fig5.add_trace(go.Bar(name="Waste (kg)", x=df_br["Branch"],
                              y=df_br["Qty_kg"], marker_color="#27AE60"))
        fig5.add_trace(go.Bar(name="Cost (RM)", x=df_br["Branch"],
                              y=df_br["Cost_RM"], marker_color="#a8d5b5",
                              yaxis="y2"))
        fig5.update_layout(
            barmode="group",
            yaxis =dict(title="Qty (kg)"),
            yaxis2=dict(title="Cost (RM)", overlaying="y", side="right"),
            legend=dict(orientation="h",y=-0.25),
            plot_bgcolor="white", paper_bgcolor="white",
            margin=dict(t=20,b=10),
            title="Branch Comparison – Waste Qty vs Cost",
        )
        st.plotly_chart(fig5, use_container_width=True)

        # radar chart – branch performance
        if len(df_br) >= 3:
            st.markdown("#### 🕸️ Branch Radar – Multi-Metric")
            metrics = ["Entries","Qty_kg","Cost_RM","Avg_Cost","UniqueItems"]
            df_norm = df_br[["Branch"]+metrics].copy()
            # cast every metric column to float (MySQL Decimal → Python object)
            for m in metrics:
                df_norm[m] = pd.to_numeric(df_norm[m], errors="coerce").fillna(0)
            for m in metrics:
                mx = float(df_norm[m].max())
                df_norm[m] = ((df_norm[m] / mx * 100).round(1)
                              if mx > 0 else pd.Series([0.0]*len(df_norm)))
            fig_rad = go.Figure()
            for _, row in df_norm.iterrows():
                fig_rad.add_trace(go.Scatterpolar(
                    r=[row[m] for m in metrics],
                    theta=metrics, fill="toself",
                    name=row["Branch"],
                ))
            fig_rad.update_layout(
                polar=dict(radialaxis=dict(visible=True, range=[0,100])),
                showlegend=True, paper_bgcolor="white",
                margin=dict(t=40,b=40),
                title="Branch Radar (normalised 0–100)",
            )
            st.plotly_chart(fig_rad, use_container_width=True)

        st.dataframe(df_br, use_container_width=True, hide_index=True)

# ─────────────────────────────────────────────────────────────
# TAB 5 – EXPORT
# ─────────────────────────────────────────────────────────────
with tabs[4]:
    st.subheader("💾 Export Data")

    export_data = run_query(
        f"""SELECT wl.WasteLogID, wl.WasteDateTime, b.BranchName,
                   i.ItemName, i.Unit, wc.TypeName AS Category,
                   wr.ReasonText AS Reason, wl.Quantity,
                   wl.EstimatedCost, u.UserName AS LoggedBy,
                   r.RoleName AS LoggedByRole, wl.Notes
            FROM WasteLog wl
            JOIN Branch        b  ON b.BranchID         = wl.BranchID
            JOIN Item          i  ON i.ItemID           = wl.ItemID
            JOIN WasteCategory wc ON wc.WasteCategoryID = wl.WasteCategoryID
            JOIN WasteReason   wr ON wr.ReasonID        = wl.ReasonID
            JOIN User          u  ON u.UserID           = wl.LoggedByUserID
            JOIN Role          r  ON r.RoleID           = u.RoleID
            WHERE 1=1 {extra_bf} {date_clause}
            ORDER BY wl.WasteDateTime DESC""",
        params,
    )

    if export_data:
        df_exp = pd.DataFrame(export_data)
        st.info(f"📄 **{len(df_exp):,}** records ready for export "
                f"({rpt_from} → {rpt_to})")
        st.dataframe(df_exp.head(25), use_container_width=True, hide_index=True)

        col1, col2 = st.columns(2)
        with col1:
            csv = df_exp.to_csv(index=False).encode("utf-8")
            st.download_button("⬇️ Download Full Waste Log CSV", data=csv,
                               file_name=f"wastelens_{rpt_from}_{rpt_to}.csv",
                               mime="text/csv", use_container_width=True)
        with col2:
            branch_sum = run_query(
                f"""SELECT b.BranchName AS Branch,
                           ROUND(SUM(wl.Quantity),2)      AS Total_Waste_kg,
                           ROUND(SUM(wl.EstimatedCost),2) AS Total_Cost_RM,
                           COUNT(*)                        AS Entries
                    FROM WasteLog wl JOIN Branch b ON b.BranchID=wl.BranchID
                    WHERE 1=1 {extra_bf} {date_clause}
                    GROUP BY b.BranchName ORDER BY Total_Cost_RM DESC""",
                params,
            )
            if branch_sum:
                csv2 = pd.DataFrame(branch_sum).to_csv(index=False).encode("utf-8")
                st.download_button("⬇️ Download Branch Summary CSV", data=csv2,
                                   file_name=f"wastelens_branch_{rpt_from}_{rpt_to}.csv",
                                   mime="text/csv", use_container_width=True)
    else:
        st.info("No data to export for the selected period.")
